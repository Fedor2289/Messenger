# 🟢 ВестиЧат — Мессенджер с ИИ-ботами

**Современный мессенджер** с поддержкой групп, каналов, файлов и ИИ-ботов (Groq/OpenAI).  
Готов к деплою на [Railway](https://railway.app) за 5 минут без написания кода.

---

## ✨ Возможности

| Функция | Описание |
|---|---|
| 💬 Чаты | Личные, групповые, каналы |
| 🤖 ИИ-боты | Groq llama3, GPT-3.5, любой OpenAI-совместимый API |
| 📎 Файлы | Фото, видео, аудио, документы до 50 МБ |
| 🔔 Реал-тайм | WebSocket — мгновенная доставка сообщений |
| 🛡 Админка | Управление пользователями, чатами и ботами |
| 🌍 Россия | Работает без VPN, хостится на Railway |
| 📱 Адаптивный | Полностью адаптирован под мобильные |

---

## 🚀 Деплой на Railway (пошагово)

### Шаг 1 — Подготовка MongoDB Atlas

1. Зайдите на [cloud.mongodb.com](https://cloud.mongodb.com)
2. Создайте **бесплатный** кластер (M0 Free Tier)
3. В разделе **Database Access** создайте пользователя (логин + пароль)
4. В разделе **Network Access** нажмите **Allow access from anywhere** (`0.0.0.0/0`)
5. В разделе **Connect → Drivers** скопируйте строку подключения:
   ```
   mongodb+srv://USER:PASSWORD@cluster0.xxxxx.mongodb.net/?retryWrites=true&w=majority
   ```
   Замените `USER` и `PASSWORD` на ваши данные, добавьте `/messenger` перед `?`:
   ```
   mongodb+srv://USER:PASSWORD@cluster0.xxxxx.mongodb.net/messenger?retryWrites=true&w=majority
   ```

### Шаг 2 — Загрузка на GitHub

1. Создайте **новый репозиторий** на [github.com](https://github.com)
2. Загрузите файлы проекта:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_NAME/vestichat.git
   git push -u origin main
   ```

### Шаг 3 — Деплой на Railway

1. Зайдите на [railway.app](https://railway.app) и войдите через GitHub
2. Нажмите **New Project → Deploy from GitHub repo**
3. Выберите ваш репозиторий
4. Railway автоматически обнаружит `railway.toml` и начнёт сборку

### Шаг 4 — Переменные окружения

В Railway откройте **Variables** и добавьте:

| Переменная | Значение | Описание |
|---|---|---|
| `MONGODB_URI` | `mongodb+srv://...` | Строка подключения MongoDB Atlas |
| `JWT_SECRET` | `минимум_32_символа_любых` | Секрет для JWT токенов |
| `NODE_ENV` | `production` | Режим запуска |
| `CLIENT_URL` | `https://your-app.up.railway.app` | URL вашего Railway приложения |
| `GROQ_API_KEY` | `gsk_...` | **Бесплатный** ключ Groq AI |
| `OPENAI_API_KEY` | `sk-...` | (Опционально) ключ OpenAI |
| `ADMIN_EMAIL` | `admin@example.com` | Email первого администратора |

> 💡 **Groq бесплатный!** Получите ключ на [console.groq.com](https://console.groq.com) — регистрация 1 минута.

### Шаг 5 — Получение URL

1. В Railway нажмите **Settings → Domains → Generate Domain**
2. Скопируйте URL вида `https://vestichat-xxx.up.railway.app`
3. Обновите переменную `CLIENT_URL` на этот адрес
4. Railway автоматически пересоберёт проект

---

## 👤 Первый вход

1. Откройте URL вашего Railway приложения
2. Нажмите **Зарегистрироваться**
3. Если email совпадает с `ADMIN_EMAIL` — вы сразу получите права **Администратора**
4. Либо первый зарегистрированный пользователь автоматически становится администратором

---

## 🤖 Настройка ИИ-ботов

### Создать стандартных ботов (рекомендуется)

1. Войдите как администратор
2. Нажмите иконку **🛡 щит** в верхнем левом углу → **Панель администратора**
3. Перейдите в раздел **Боты**
4. Нажмите кнопку **"Создать стандартных ботов"**
5. Будут созданы два бота:
   - **Помощник** — отвечает на вопросы
   - **Игровой Бот** — загадки, викторина, приключения

### Добавить бота в чат

1. Откройте любой чат или создайте группу
2. Нажмите иконку **ℹ️** (информация) в шапке чата
3. Перейдите на вкладку **Боты**
4. Нажмите **+ Добавить** рядом с нужным ботом
5. Теперь пишите боту! Примеры:
   - `@assistant_bot помоги`
   - `/story` — случайная история
   - `/riddle` — загадка
   - `/trivia` — викторина
   - `/help` — список команд

### Создать своего бота с API

1. Перейдите в **Настройки** (иконка шестерёнки в боковой панели)
2. Или через API: `POST /api/bots` с параметрами:
   ```json
   {
     "name": "Мой Бот",
     "username": "mybot",
     "apiType": "groq",
     "apiKey": "gsk_ваш_ключ",
     "model": "llama3-8b-8192",
     "systemPrompt": "Ты весёлый помощник. Отвечай на русском.",
     "triggers": ["привет", "help"]
   }
   ```

---

## 💬 Использование мессенджера

### Создание чатов

| Тип | Как создать |
|---|---|
| Личный чат | Нажать ➕ → выбрать **Личный чат** → найти пользователя |
| Группа | Нажать ➕ → **Группа** → ввести название → добавить участников |
| Канал | Нажать ➕ → **Канал** → ввести название |

### Команды ботов

```
/help      — список команд
/story     — случайная история (Horror, Sci-Fi, Fantasy)
/riddle    — загадка с ответом
/trivia    — вопрос для викторины
/adventure — мини-приключение с выбором
```

### Отправка файлов

- Нажмите скрепку 📎 в поле ввода
- Поддерживаются: фото, видео, аудио, PDF, Word, Excel, ZIP до 50 МБ

---

## 🛡 Панель администратора

Доступна по адресу: `https://your-app.up.railway.app/admin`

- **Статистика** — пользователи, чаты, сообщения онлайн
- **Пользователи** — блокировка, смена роли (user/moderator/admin)
- **Чаты** — просмотр и удаление всех чатов
- **Боты** — управление ботами, включение глобального доступа

---

## 🔧 Локальный запуск (для разработчиков)

```bash
# 1. Установить зависимости
cd backend && npm install
cd ../frontend && npm install

# 2. Настроить backend/.env (скопировать из .env.example)
cp backend/.env.example backend/.env
# Заполнить MONGODB_URI, JWT_SECRET и т.д.

# 3. Запустить
# Терминал 1:
cd backend && npm run dev

# Терминал 2:
cd frontend && npm run dev

# Открыть http://localhost:3000
```

---

## 📁 Структура проекта

```
vestichat/
├── backend/
│   ├── server.js              # Точка входа Express + Socket.io
│   ├── src/
│   │   ├── config/db.js       # Подключение MongoDB
│   │   ├── models/            # User, Chat, Message, Bot
│   │   ├── routes/            # REST API маршруты
│   │   ├── middleware/        # auth.js, upload.js
│   │   ├── socket/index.js    # WebSocket обработчики
│   │   └── services/ai.js     # ИИ интеграция (Groq/OpenAI)
│   └── uploads/               # Загруженные файлы
├── frontend/
│   ├── src/
│   │   ├── pages/             # LoginPage, RegisterPage, MessengerPage, AdminPage
│   │   ├── components/
│   │   │   ├── chat/          # Sidebar, ChatWindow, MessageBubble, ...
│   │   │   └── ui/            # Avatar и общие компоненты
│   │   ├── contexts/          # AuthContext
│   │   └── services/          # api.js, socket.js
│   └── dist/                  # Сборка (создаётся при деплое)
├── railway.toml               # Конфиг Railway
├── nixpacks.toml              # Конфиг сборки
└── README.md
```

---

## 🌐 API Endpoints (краткий список)

```
POST /api/auth/register     — Регистрация
POST /api/auth/login        — Вход
GET  /api/chats             — Список чатов
POST /api/chats             — Создать чат
GET  /api/messages/:chatId  — Сообщения чата
POST /api/messages          — Отправить сообщение
POST /api/files/upload      — Загрузить файл
GET  /api/bots              — Список ботов
POST /api/bots              — Создать бота
GET  /api/admin/stats       — Статистика (admin)
```

---

## ❓ Частые вопросы

**Q: Не запускается на Railway?**  
A: Проверьте переменную `MONGODB_URI` — она должна содержать `/messenger?` в пути.

**Q: Бот не отвечает?**  
A: Убедитесь, что `GROQ_API_KEY` добавлен в переменные Railway и бот добавлен в чат.

**Q: Как получить права администратора?**  
A: Первый зарегистрированный пользователь — автоматически администратор. Или задайте `ADMIN_EMAIL`.

**Q: Можно ли использовать другой ИИ?**  
A: Да! При создании бота выберите `apiType: "custom"` и укажите `apiUrl` любого OpenAI-совместимого API.

---

## 📜 Лицензия

MIT — используйте свободно для личных и коммерческих проектов.
