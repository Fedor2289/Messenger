const axios = require('axios');
const Message = require('../models/Message');
const Chat = require('../models/Chat');

// ============================================================
// Core AI caller - supports Groq and OpenAI-compatible APIs
// ============================================================
const callAI = async (bot, userMessage, history = []) => {
  const apiKey = bot.apiKey || process.env.GROQ_API_KEY || process.env.OPENAI_API_KEY;

  if (!apiKey && bot.apiType !== 'builtin') {
    return generateBuiltinResponse(userMessage, bot);
  }

  let apiUrl, headers, model;

  if (bot.apiType === 'groq') {
    apiUrl = 'https://api.groq.com/openai/v1/chat/completions';
    headers = { Authorization: `Bearer ${apiKey || process.env.GROQ_API_KEY}` };
    model = bot.model || 'llama3-8b-8192';
  } else if (bot.apiType === 'openai') {
    apiUrl = 'https://api.openai.com/v1/chat/completions';
    headers = { Authorization: `Bearer ${apiKey || process.env.OPENAI_API_KEY}` };
    model = bot.model || 'gpt-3.5-turbo';
  } else if (bot.apiType === 'custom' && bot.apiUrl) {
    apiUrl = bot.apiUrl;
    headers = apiKey ? { Authorization: `Bearer ${apiKey}` } : {};
    model = bot.model || 'default';
  } else {
    return generateBuiltinResponse(userMessage, bot);
  }

  const messages = [
    { role: 'system', content: bot.systemPrompt || 'You are a helpful assistant.' },
    ...history.slice(-6).map(m => ({
      role: m.sender ? 'user' : 'assistant',
      content: m.content,
    })),
    { role: 'user', content: userMessage },
  ];

  try {
    const response = await axios.post(
      apiUrl,
      { model, messages, max_tokens: 800, temperature: 0.8 },
      { headers: { ...headers, 'Content-Type': 'application/json' }, timeout: 30000 }
    );

    return response.data.choices?.[0]?.message?.content?.trim() ||
      'Не удалось получить ответ от ИИ.';
  } catch (error) {
    console.error('AI API error:', error.response?.data || error.message);

    if (error.response?.status === 429) return '⏳ Слишком много запросов. Попробуй позже.';
    if (error.response?.status === 401) return '🔑 Ошибка API ключа. Проверь настройки бота.';
    if (error.code === 'ECONNABORTED') return '⏰ Превышено время ожидания. Попробуй снова.';

    return generateBuiltinResponse(userMessage, bot);
  }
};

// ============================================================
// Built-in fallback responses (no API key needed)
// ============================================================
const generateBuiltinResponse = (message, bot) => {
  const msg = message.toLowerCase();

  // Commands
  if (msg.startsWith('/story') || msg.includes('расскажи историю') || msg.includes('история')) {
    return generateStory();
  }
  if (msg.startsWith('/riddle') || msg.includes('загадка') || msg.includes('загадай')) {
    return generateRiddle();
  }
  if (msg.startsWith('/trivia') || msg.includes('викторина') || msg.includes('вопрос')) {
    return generateTrivia();
  }
  if (msg.startsWith('/adventure') || msg.includes('приключение')) {
    return generateAdventure();
  }
  if (msg.startsWith('/help') || msg.includes('помощь') || msg.includes('помоги')) {
    return `🤖 **${bot.name}** здесь!

Доступные команды:
/story — случайная история
/riddle — загадка
/trivia — вопрос для викторины
/adventure — мини-приключение
/help — это сообщение

Просто напиши мне что-нибудь! 😊`;
  }

  // Greetings
  if (msg.match(/^(привет|хай|hello|hi|hey|здравствуй)/)) {
    const greetings = [
      'Привет! 👋 Чем могу помочь?',
      'Привет! Рад тебя видеть 😊',
      'Хей! Как дела? 🌟',
      'Hello! Готов помочь! 🤖',
    ];
    return greetings[Math.floor(Math.random() * greetings.length)];
  }

  // Default responses
  const defaults = [
    '💭 Интересно! Расскажи подробнее?',
    '🤔 Хм, понял. А что ты имеешь в виду?',
    '😊 Окей! Могу помочь с историями (/story), загадками (/riddle) или викториной (/trivia)',
    '🌟 Напиши /help чтобы узнать что я умею!',
    '💬 Интересно! Могу рассказать историю — напиши /story',
  ];
  return defaults[Math.floor(Math.random() * defaults.length)];
};

const generateStory = () => {
  const stories = [
    `📖 **Тёмный лес**\n\nОднажды ночью путник заблудился в лесу. Деревья шептали его имя, и тропа исчезла под ногами. Вдруг он увидел огонёк — избушка! Постучал. Дверь открылась сама... *Что дальше?* 🌙`,
    `🚀 **Последняя станция**\n\nКосмонавт Алекс получил сигнал SOS с заброшенной станции. Приблизившись, он увидел: все системы работают, еда свежая, но людей нет. Только на запотевшем иллюминаторе — слова: *"Не ищи нас"*. 🛸`,
    `🏰 **Зеркало Истины**\n\nВ старом замке нашли зеркало, которое показывало не отражение, а будущее. Принцесса заглянула и отшатнулась. В зеркале — она сама, только в короне... и в тюремной камере. ⚔️`,
  ];
  return stories[Math.floor(Math.random() * stories.length)];
};

const generateRiddle = () => {
  const riddles = [
    '🧩 **Загадка:**\nЧем больше берёшь — тем больше становится. Что это?\n\n<spoiler>Яма!</spoiler>',
    '🧩 **Загадка:**\nЕсть у меня слуги: день и ночь они идут, а с места не сдвинутся. Что это?\n\n||Часы!||',
    '🧩 **Загадка:**\nВ воде родилась, воды боится. Что это?\n\n||Соль!||',
    '🧩 **Загадка:**\nДва кольца, два конца, а посередине гвоздик. Что это?\n\n||Ножницы!||',
  ];
  return riddles[Math.floor(Math.random() * riddles.length)];
};

const generateTrivia = () => {
  const questions = [
    '❓ **Викторина:**\nСколько планет в Солнечной системе?\nА) 7  Б) 8  В) 9\n\n||Правильный ответ: Б) 8||',
    '❓ **Викторина:**\nКакая самая длинная река в мире?\nА) Амазонка  Б) Нил  В) Янцзы\n\n||Правильный ответ: Б) Нил (~6 650 км)||',
    '❓ **Викторина:**\nВ каком году запустили первый спутник Земли?\nА) 1955  Б) 1957  В) 1961\n\n||Правильный ответ: Б) 1957 (СССР)||',
    '❓ **Викторина:**\nСколько костей в теле взрослого человека?\nА) 206  Б) 220  В) 196\n\n||Правильный ответ: А) 206||',
  ];
  return questions[Math.floor(Math.random() * questions.length)];
};

const generateAdventure = () => {
  const adventures = [
    `⚔️ **Мини-приключение: Развилка**\n\nТы стоишь на развилке в подземелье. Налево слышен плеск воды, направо — запах горящего дерева.\n\n🔵 Напиши "налево" или "направо" — и я продолжу историю!`,
    `🌊 **Мини-приключение: Корабль**\n\nТы на старинном корабле. Внезапно шторм! Видишь два выхода: люк в трюм или верёвка на мачте.\n\n🔵 Что делаешь?`,
  ];
  return adventures[Math.floor(Math.random() * adventures.length)];
};

// ============================================================
// Process incoming message and check if bots should respond
// ============================================================
const processBotMessage = async (chat, message, sender, io) => {
  if (!chat.bots || chat.bots.length === 0) return;
  if (message.type !== 'text' || !message.content) return;

  // Small delay to feel natural
  await new Promise(r => setTimeout(r, 800 + Math.random() * 1200));

  for (const bot of chat.bots) {
    if (!bot.isActive) continue;

    const content = message.content.toLowerCase();
    const botMention = content.includes(`@${bot.username}`) || content.includes(bot.name.toLowerCase());
    const isCommand = content.startsWith('/');
    const triggerMatch = bot.triggers?.some(t => content.includes(t.toLowerCase()));

    // Bot responds to: direct mentions, commands, or trigger keywords
    if (!botMention && !isCommand && !triggerMatch) continue;

    // Get recent chat history for context
    const history = await Message.find({
      chatId: chat._id,
      deleted: false,
    })
      .sort({ createdAt: -1 })
      .limit(8)
      .lean();

    const response = await callAI(bot, message.content, history.reverse());

    const botMessage = await Message.create({
      chatId: chat._id,
      bot: bot._id,
      sender: null,
      content: response,
      type: 'bot',
      readBy: [],
    });

    await botMessage.populate('bot', 'name username avatar');

    await Chat.findByIdAndUpdate(chat._id, {
      lastMessage: botMessage._id,
      lastActivity: new Date(),
    });

    await bot.updateOne({ $inc: { 'stats.messagesHandled': 1 } });

    if (io) {
      io.to(chat._id.toString()).emit('new_message', {
        message: botMessage,
        chatId: chat._id.toString(),
      });
    }
  }
};

module.exports = { callAI, processBotMessage };
