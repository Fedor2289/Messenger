const mongoose = require('mongoose');

const chatSchema = new mongoose.Schema({
  name: {
    type: String,
    trim: true,
    default: null,
  },
  type: {
    type: String,
    enum: ['direct', 'group', 'channel'],
    required: true,
  },
  description: {
    type: String,
    default: '',
    maxlength: 500,
  },
  avatar: {
    type: String,
    default: null,
  },
  members: [{
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    role: { type: String, enum: ['owner', 'admin', 'member'], default: 'member' },
    joinedAt: { type: Date, default: Date.now },
    muted: { type: Boolean, default: false },
  }],
  // Bots in this chat
  bots: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Bot',
  }],
  lastMessage: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Message',
    default: null,
  },
  lastActivity: {
    type: Date,
    default: Date.now,
  },
  isPublic: {
    type: Boolean,
    default: false,
  },
  inviteLink: {
    type: String,
    default: null,
  },
  pinnedMessages: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Message',
  }],
  settings: {
    slowMode: { type: Number, default: 0 }, // seconds
    onlyAdminsPost: { type: Boolean, default: false },
  },
}, { timestamps: true });

// Index for faster queries
chatSchema.index({ 'members.user': 1 });
chatSchema.index({ type: 1 });
chatSchema.index({ lastActivity: -1 });

module.exports = mongoose.model('Chat', chatSchema);
