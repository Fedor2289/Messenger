const mongoose = require('mongoose');

const botSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true,
  },
  username: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    lowercase: true,
  },
  description: {
    type: String,
    default: '',
    maxlength: 500,
  },
  avatar: {
    type: String,
    default: null,
  },
  // AI configuration
  apiType: {
    type: String,
    enum: ['groq', 'openai', 'custom', 'builtin'],
    default: 'groq',
  },
  apiKey: {
    type: String,
    default: null,
  },
  apiUrl: {
    type: String,
    default: null, // For custom OpenAI-compatible APIs
  },
  model: {
    type: String,
    default: 'llama3-8b-8192',
  },
  systemPrompt: {
    type: String,
    default: 'You are a helpful assistant in a messenger app. Be concise, friendly, and helpful. Respond in the same language as the user.',
    maxlength: 2000,
  },
  // Bot capabilities
  capabilities: {
    stories: { type: Boolean, default: true },
    games: { type: Boolean, default: true },
    weather: { type: Boolean, default: false },
    imageGen: { type: Boolean, default: false },
  },
  // Commands the bot understands
  commands: [{
    command: String,  // e.g. "/story"
    description: String,
    handler: String,  // builtin handler name
  }],
  // Trigger keywords (bot responds to these)
  triggers: [{
    type: String,
    lowercase: true,
  }],
  // Who created this bot
  owner: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null,
  },
  isGlobal: {
    type: Boolean,
    default: false, // Global bots available to all users
  },
  isActive: {
    type: Boolean,
    default: true,
  },
  stats: {
    messagesHandled: { type: Number, default: 0 },
    chatsActive: { type: Number, default: 0 },
  },
}, { timestamps: true });

module.exports = mongoose.model('Bot', botSchema);
