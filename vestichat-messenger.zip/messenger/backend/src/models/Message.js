const mongoose = require('mongoose');

const messageSchema = new mongoose.Schema({
  chatId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Chat',
    required: true,
  },
  sender: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null, // null for bot messages
  },
  bot: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Bot',
    default: null, // null for user messages
  },
  content: {
    type: String,
    default: '',
    maxlength: 10000,
  },
  type: {
    type: String,
    enum: ['text', 'image', 'file', 'voice', 'video', 'system', 'bot'],
    default: 'text',
  },
  // File attachment
  attachment: {
    url: String,
    filename: String,
    originalName: String,
    mimeType: String,
    size: Number, // bytes
  },
  // Reply to message
  replyTo: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Message',
    default: null,
  },
  // Read receipts
  readBy: [{
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    readAt: { type: Date, default: Date.now },
  }],
  edited: {
    type: Boolean,
    default: false,
  },
  editedAt: {
    type: Date,
    default: null,
  },
  deleted: {
    type: Boolean,
    default: false,
  },
  // Reactions
  reactions: [{
    emoji: String,
    users: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  }],
}, { timestamps: true });

messageSchema.index({ chatId: 1, createdAt: -1 });
messageSchema.index({ sender: 1 });

module.exports = mongoose.model('Message', messageSchema);
