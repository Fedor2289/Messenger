const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Message = require('../models/Message');
const Chat = require('../models/Chat');
const { processBotMessage } = require('../services/ai');

const setupSocket = (io) => {
  // Auth middleware for socket
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth?.token || socket.handshake.query?.token;
      if (!token) return next(new Error('No token'));
      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'fallback_secret_change_me');
      const user = await User.findById(decoded.id).select('-password');
      if (!user || !user.isActive) return next(new Error('Invalid user'));
      socket.user = user;
      next();
    } catch (err) {
      next(new Error('Authentication error'));
    }
  });

  io.on('connection', async (socket) => {
    const user = socket.user;
    console.log(`🔌 User connected: ${user.username} (${socket.id})`);

    // Update user status
    await User.findByIdAndUpdate(user._id, {
      status: 'online',
      socketId: socket.id,
      lastSeen: new Date(),
    });

    // Join all user's chat rooms
    const chats = await Chat.find({ 'members.user': user._id }).select('_id');
    chats.forEach(chat => socket.join(chat._id.toString()));

    // Notify others that user is online
    socket.broadcast.emit('user_status', {
      userId: user._id,
      status: 'online',
      lastSeen: new Date(),
    });

    // ──── SEND MESSAGE ────
    socket.on('send_message', async (data) => {
      try {
        const { chatId, content, type = 'text', replyTo } = data;
        if (!chatId || (!content && type === 'text')) return;

        const chat = await Chat.findOne({
          _id: chatId,
          'members.user': user._id,
        }).populate('bots');

        if (!chat) return socket.emit('error', { message: 'Chat not found or access denied' });

        // Channel: only admins/owners can post if onlyAdminsPost
        if (chat.type === 'channel' && chat.settings?.onlyAdminsPost) {
          const member = chat.members.find(m => m.user.toString() === user._id.toString());
          if (!['owner', 'admin'].includes(member?.role)) {
            return socket.emit('error', { message: 'Only admins can post in this channel' });
          }
        }

        const message = await Message.create({
          chatId,
          sender: user._id,
          content,
          type,
          replyTo: replyTo || null,
          readBy: [{ user: user._id }],
        });

        await message.populate('sender', 'username displayName avatar');
        if (replyTo) await message.populate('replyTo');

        await Chat.findByIdAndUpdate(chatId, {
          lastMessage: message._id,
          lastActivity: new Date(),
        });

        // Broadcast to all in chat room
        io.to(chatId).emit('new_message', { message, chatId });

        // Process bot responses
        if (chat.bots?.length > 0 && type === 'text') {
          processBotMessage(chat, message, user, io).catch(console.error);
        }
      } catch (err) {
        console.error('send_message error:', err);
        socket.emit('error', { message: 'Failed to send message' });
      }
    });

    // ──── TYPING INDICATORS ────
    socket.on('typing_start', ({ chatId }) => {
      socket.to(chatId).emit('user_typing', {
        userId: user._id,
        username: user.displayName,
        chatId,
      });
    });

    socket.on('typing_stop', ({ chatId }) => {
      socket.to(chatId).emit('user_stop_typing', {
        userId: user._id,
        chatId,
      });
    });

    // ──── READ MESSAGES ────
    socket.on('read_messages', async ({ chatId }) => {
      try {
        await Message.updateMany(
          {
            chatId,
            'readBy.user': { $ne: user._id },
            sender: { $ne: user._id },
          },
          { $addToSet: { readBy: { user: user._id, readAt: new Date() } } }
        );
        io.to(chatId).emit('messages_read', { chatId, userId: user._id });
      } catch (err) {
        console.error('read_messages error:', err);
      }
    });

    // ──── JOIN CHAT ROOM ────
    socket.on('join_chat', async ({ chatId }) => {
      const chat = await Chat.findOne({ _id: chatId, 'members.user': user._id });
      if (chat) {
        socket.join(chatId);
        socket.emit('joined_chat', { chatId });
      }
    });

    // ──── LEAVE CHAT ROOM ────
    socket.on('leave_chat', ({ chatId }) => {
      socket.leave(chatId);
    });

    // ──── REACT TO MESSAGE ────
    socket.on('react_message', async ({ messageId, emoji }) => {
      try {
        const message = await Message.findById(messageId);
        if (!message) return;

        let reaction = message.reactions.find(r => r.emoji === emoji);
        if (!reaction) {
          message.reactions.push({ emoji, users: [user._id] });
        } else {
          const idx = reaction.users.map(u => u.toString()).indexOf(user._id.toString());
          if (idx > -1) {
            reaction.users.splice(idx, 1);
            if (reaction.users.length === 0) {
              message.reactions = message.reactions.filter(r => r.emoji !== emoji);
            }
          } else {
            reaction.users.push(user._id);
          }
        }
        await message.save();
        io.to(message.chatId.toString()).emit('message_reaction', {
          messageId,
          reactions: message.reactions,
        });
      } catch (err) {
        console.error('react error:', err);
      }
    });

    // ──── EDIT MESSAGE ────
    socket.on('edit_message', async ({ messageId, content }) => {
      try {
        const message = await Message.findOne({ _id: messageId, sender: user._id });
        if (!message) return;
        message.content = content;
        message.edited = true;
        message.editedAt = new Date();
        await message.save();
        io.to(message.chatId.toString()).emit('message_edited', { message });
      } catch (err) {
        console.error('edit error:', err);
      }
    });

    // ──── DELETE MESSAGE ────
    socket.on('delete_message', async ({ messageId }) => {
      try {
        const message = await Message.findOne({ _id: messageId, sender: user._id });
        if (!message) return;
        message.deleted = true;
        message.content = 'Сообщение удалено';
        await message.save();
        io.to(message.chatId.toString()).emit('message_deleted', {
          messageId,
          chatId: message.chatId,
        });
      } catch (err) {
        console.error('delete error:', err);
      }
    });

    // ──── DISCONNECT ────
    socket.on('disconnect', async () => {
      console.log(`❌ User disconnected: ${user.username}`);
      await User.findByIdAndUpdate(user._id, {
        status: 'offline',
        socketId: null,
        lastSeen: new Date(),
      });
      io.emit('user_status', {
        userId: user._id,
        status: 'offline',
        lastSeen: new Date(),
      });
    });
  });
};

module.exports = setupSocket;
