const express = require('express');
const Bot = require('../models/Bot');
const { auth } = require('../middleware/auth');

const router = express.Router();

// GET /api/bots - get available bots
router.get('/', auth, async (req, res) => {
  try {
    const bots = await Bot.find({
      $or: [
        { isGlobal: true },
        { owner: req.user._id },
      ],
      isActive: true,
    }).populate('owner', 'username displayName');
    res.json({ bots });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/bots/:id
router.get('/:id', auth, async (req, res) => {
  try {
    const bot = await Bot.findById(req.params.id).populate('owner', 'username displayName');
    if (!bot) return res.status(404).json({ error: 'Bot not found' });
    // Hide apiKey from non-owners
    if (bot.owner?.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      bot.apiKey = undefined;
    }
    res.json({ bot });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /api/bots - create bot
router.post('/', auth, async (req, res) => {
  try {
    const {
      name, username, description, apiType, apiKey, apiUrl,
      model, systemPrompt, capabilities, triggers, commands, isGlobal,
    } = req.body;

    if (!name || !username) {
      return res.status(400).json({ error: 'Name and username are required' });
    }

    const existing = await Bot.findOne({ username: username.toLowerCase() });
    if (existing) return res.status(409).json({ error: 'Bot username already taken' });

    const bot = await Bot.create({
      name,
      username: username.toLowerCase(),
      description,
      apiType: apiType || 'groq',
      apiKey,
      apiUrl,
      model: model || 'llama3-8b-8192',
      systemPrompt: systemPrompt || 'You are a helpful assistant. Be friendly and concise.',
      capabilities: capabilities || { stories: true, games: true },
      triggers: triggers || [],
      commands: commands || [],
      owner: req.user._id,
      isGlobal: req.user.role === 'admin' ? (isGlobal || false) : false,
    });

    res.status(201).json({ bot });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// PUT /api/bots/:id
router.put('/:id', auth, async (req, res) => {
  try {
    const bot = await Bot.findById(req.params.id);
    if (!bot) return res.status(404).json({ error: 'Bot not found' });

    if (bot.owner?.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Not authorized' });
    }

    const fields = ['name', 'description', 'apiType', 'apiKey', 'apiUrl',
      'model', 'systemPrompt', 'capabilities', 'triggers', 'commands'];
    fields.forEach(f => {
      if (req.body[f] !== undefined) bot[f] = req.body[f];
    });

    if (req.user.role === 'admin' && req.body.isGlobal !== undefined) {
      bot.isGlobal = req.body.isGlobal;
    }

    await bot.save();
    res.json({ bot });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// DELETE /api/bots/:id
router.delete('/:id', auth, async (req, res) => {
  try {
    const bot = await Bot.findById(req.params.id);
    if (!bot) return res.status(404).json({ error: 'Bot not found' });

    if (bot.owner?.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Not authorized' });
    }

    await bot.deleteOne();
    res.json({ message: 'Bot deleted' });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /api/bots/:id/test - test bot response
router.post('/:id/test', auth, async (req, res) => {
  try {
    const { message } = req.body;
    const bot = await Bot.findById(req.params.id);
    if (!bot) return res.status(404).json({ error: 'Bot not found' });

    const { callAI } = require('../services/ai');
    const response = await callAI(bot, message, []);
    res.json({ response });
  } catch (error) {
    res.status(500).json({ error: error.message || 'AI call failed' });
  }
});

module.exports = router;
