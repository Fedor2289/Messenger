const express = require('express');
const User = require('../models/User');
const { auth } = require('../middleware/auth');

const router = express.Router();

// GET /api/users - search users
router.get('/', auth, async (req, res) => {
  try {
    const { search, limit = 20 } = req.query;
    let query = { _id: { $ne: req.user._id }, isActive: true };

    if (search) {
      query.$or = [
        { username: { $regex: search, $options: 'i' } },
        { displayName: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
      ];
    }

    const users = await User.find(query)
      .select('-password -socketId')
      .limit(parseInt(limit))
      .sort({ displayName: 1 });

    res.json({ users });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/users/:id
router.get('/:id', auth, async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('-password -socketId');
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json({ user });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/users/online/list
router.get('/online/list', auth, async (req, res) => {
  try {
    const users = await User.find({ status: 'online', isActive: true })
      .select('username displayName avatar status lastSeen')
      .limit(50);
    res.json({ users });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
