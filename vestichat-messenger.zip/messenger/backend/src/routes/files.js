const express = require('express');
const path = require('path');
const Chat = require('../models/Chat');
const Message = require('../models/Message');
const upload = require('../middleware/upload');
const { auth } = require('../middleware/auth');

const router = express.Router();

// POST /api/files/upload - upload file in chat
router.post('/upload', auth, upload.single('file'), async (req, res) => {
  try {
    const { chatId } = req.body;
    if (!req.file) return res.status(400).json({ error: 'No file provided' });

    const chat = await Chat.findOne({ _id: chatId, 'members.user': req.user._id });
    if (!chat) return res.status(403).json({ error: 'Access denied' });

    const baseUrl = process.env.BASE_URL ||
      `${req.protocol}://${req.get('host')}`;
    const relPath = req.file.path.replace(path.join(__dirname, '..', '..'), '');
    const fileUrl = `${baseUrl}${relPath.replace(/\\/g, '/')}`;

    // Determine message type
    let msgType = 'file';
    const mime = req.file.mimetype;
    if (mime.startsWith('image/')) msgType = 'image';
    else if (mime.startsWith('audio/')) msgType = 'voice';
    else if (mime.startsWith('video/')) msgType = 'video';

    const message = await Message.create({
      chatId,
      sender: req.user._id,
      content: req.file.originalname,
      type: msgType,
      attachment: {
        url: fileUrl,
        filename: req.file.filename,
        originalName: req.file.originalname,
        mimeType: req.file.mimetype,
        size: req.file.size,
      },
      readBy: [{ user: req.user._id }],
    });

    await message.populate('sender', 'username displayName avatar');

    await Chat.findByIdAndUpdate(chatId, {
      lastMessage: message._id,
      lastActivity: new Date(),
    });

    const io = req.app.get('io');
    if (io) {
      io.to(chatId).emit('new_message', { message, chatId });
    }

    res.status(201).json({
      message,
      file: {
        url: fileUrl,
        originalName: req.file.originalname,
        mimeType: req.file.mimetype,
        size: req.file.size,
      },
    });
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ error: error.message || 'Upload failed' });
  }
});

// POST /api/files/avatar - upload avatar
router.post('/avatar', auth, upload.single('avatar'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file provided' });

    const baseUrl = process.env.BASE_URL || `${req.protocol}://${req.get('host')}`;
    const relPath = req.file.path.replace(path.join(__dirname, '..', '..'), '');
    const avatarUrl = `${baseUrl}${relPath.replace(/\\/g, '/')}`;

    res.json({ url: avatarUrl });
  } catch (error) {
    res.status(500).json({ error: 'Upload failed' });
  }
});

module.exports = router;
