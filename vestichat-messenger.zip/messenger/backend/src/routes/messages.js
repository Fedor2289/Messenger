const express = require('express');
const Message = require('../models/Message');
const Chat = require('../models/Chat');
const { auth } = require('../middleware/auth');
const { processBotMessage } = require('../services/ai');

const router = express.Router();

// GET /api/messages/:chatId
router.get('/:chatId', auth, async (req, res) => {
  try {
    const { page = 1, limit = 50 } = req.query;

    const chat = await Chat.findOne({
      _id: req.params.chatId,
      'members.user': req.user._id,
    });
    if (!chat) return res.status(403).json({ error: 'Access denied' });

    const messages = await Message.find({
      chatId: req.params.chatId,
      deleted: false,
    })
      .populate('sender', 'username displayName avatar')
      .populate('bot', 'name username avatar')
      .populate('replyTo')
      .sort({ createdAt: -1 })
      .limit(parseInt(limit))
      .skip((parseInt(page) - 1) * parseInt(limit));

    const total = await Message.countDocuments({
      chatId: req.params.chatId,
      deleted: false,
    });

    // Mark messages as read
    await Message.updateMany(
      {
        chatId: req.params.chatId,
        'readBy.user': { $ne: req.user._id },
        sender: { $ne: req.user._id },
      },
      { $addToSet: { readBy: { user: req.user._id, readAt: new Date() } } }
    );

    res.json({
      messages: messages.reverse(),
      total,
      pages: Math.ceil(total / parseInt(limit)),
      page: parseInt(page),
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /api/messages - send message (REST fallback)
router.post('/', auth, async (req, res) => {
  try {
    const { chatId, content, type = 'text', replyTo } = req.body;

    const chat = await Chat.findOne({
      _id: chatId,
      'members.user': req.user._id,
    }).populate('bots');

    if (!chat) return res.status(403).json({ error: 'Access denied' });

    if (!content && type === 'text') {
      return res.status(400).json({ error: 'Message content is required' });
    }

    const message = await Message.create({
      chatId,
      sender: req.user._id,
      content,
      type,
      replyTo: replyTo || null,
      readBy: [{ user: req.user._id }],
    });

    await message.populate('sender', 'username displayName avatar');
    await message.populate('replyTo');

    // Update chat last activity
    await Chat.findByIdAndUpdate(chatId, {
      lastMessage: message._id,
      lastActivity: new Date(),
    });

    // Emit via socket
    const io = req.app.get('io');
    if (io) {
      io.to(chatId).emit('new_message', { message, chatId });
    }

    // Process bot responses
    if (chat.bots && chat.bots.length > 0 && type === 'text') {
      processBotMessage(chat, message, req.user, io).catch(console.error);
    }

    res.status(201).json({ message });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error' });
  }
});

// PUT /api/messages/:id - edit message
router.put('/:id', auth, async (req, res) => {
  try {
    const { content } = req.body;
    const message = await Message.findOne({
      _id: req.params.id,
      sender: req.user._id,
      deleted: false,
    });

    if (!message) return res.status(404).json({ error: 'Message not found' });

    message.content = content;
    message.edited = true;
    message.editedAt = new Date();
    await message.save();

    const io = req.app.get('io');
    if (io) {
      io.to(message.chatId.toString()).emit('message_edited', { message });
    }

    res.json({ message });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// DELETE /api/messages/:id
router.delete('/:id', auth, async (req, res) => {
  try {
    const message = await Message.findOne({ _id: req.params.id, sender: req.user._id });
    if (!message) return res.status(404).json({ error: 'Message not found or not authorized' });

    message.deleted = true;
    message.content = 'This message was deleted';
    await message.save();

    const io = req.app.get('io');
    if (io) {
      io.to(message.chatId.toString()).emit('message_deleted', {
        messageId: message._id,
        chatId: message.chatId,
      });
    }

    res.json({ message: 'Message deleted' });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /api/messages/:id/react - add reaction
router.post('/:id/react', auth, async (req, res) => {
  try {
    const { emoji } = req.body;
    const message = await Message.findById(req.params.id);
    if (!message) return res.status(404).json({ error: 'Message not found' });

    let reaction = message.reactions.find(r => r.emoji === emoji);
    if (!reaction) {
      message.reactions.push({ emoji, users: [req.user._id] });
    } else {
      const userIndex = reaction.users.indexOf(req.user._id);
      if (userIndex > -1) {
        reaction.users.splice(userIndex, 1);
        if (reaction.users.length === 0) {
          message.reactions = message.reactions.filter(r => r.emoji !== emoji);
        }
      } else {
        reaction.users.push(req.user._id);
      }
    }
    await message.save();

    const io = req.app.get('io');
    if (io) {
      io.to(message.chatId.toString()).emit('message_reaction', {
        messageId: message._id,
        reactions: message.reactions,
      });
    }

    res.json({ reactions: message.reactions });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
