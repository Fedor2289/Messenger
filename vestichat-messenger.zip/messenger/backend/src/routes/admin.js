const express = require('express');
const User = require('../models/User');
const Chat = require('../models/Chat');
const Message = require('../models/Message');
const Bot = require('../models/Bot');
const { auth, requireAdmin } = require('../middleware/auth');

const router = express.Router();

// All admin routes require admin role
router.use(auth, requireAdmin);

// GET /api/admin/stats
router.get('/stats', async (req, res) => {
  try {
    const [users, chats, messages, bots] = await Promise.all([
      User.countDocuments(),
      Chat.countDocuments(),
      Message.countDocuments({ deleted: false }),
      Bot.countDocuments(),
    ]);
    const online = await User.countDocuments({ status: 'online' });
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const newToday = await User.countDocuments({ createdAt: { $gte: today } });

    res.json({ stats: { users, chats, messages, bots, online, newToday } });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/admin/users
router.get('/users', async (req, res) => {
  try {
    const { page = 1, limit = 20, search, role } = req.query;
    const query = {};
    if (search) {
      query.$or = [
        { username: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
        { displayName: { $regex: search, $options: 'i' } },
      ];
    }
    if (role) query.role = role;

    const users = await User.find(query)
      .select('-password')
      .sort({ createdAt: -1 })
      .limit(parseInt(limit))
      .skip((parseInt(page) - 1) * parseInt(limit));

    const total = await User.countDocuments(query);
    res.json({ users, total, pages: Math.ceil(total / parseInt(limit)) });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// PUT /api/admin/users/:id
router.put('/users/:id', async (req, res) => {
  try {
    const { role, isActive } = req.body;
    const updates = {};
    if (role) updates.role = role;
    if (isActive !== undefined) updates.isActive = isActive;

    const user = await User.findByIdAndUpdate(req.params.id, updates, { new: true }).select('-password');
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json({ user });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// DELETE /api/admin/users/:id
router.delete('/users/:id', async (req, res) => {
  try {
    if (req.params.id === req.user._id.toString()) {
      return res.status(400).json({ error: 'Cannot delete your own account' });
    }
    await User.findByIdAndUpdate(req.params.id, { isActive: false });
    res.json({ message: 'User deactivated' });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/admin/chats
router.get('/chats', async (req, res) => {
  try {
    const { page = 1, limit = 20 } = req.query;
    const chats = await Chat.find()
      .populate('members.user', 'username displayName')
      .sort({ lastActivity: -1 })
      .limit(parseInt(limit))
      .skip((parseInt(page) - 1) * parseInt(limit));

    const total = await Chat.countDocuments();
    res.json({ chats, total, pages: Math.ceil(total / parseInt(limit)) });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// DELETE /api/admin/chats/:id
router.delete('/chats/:id', async (req, res) => {
  try {
    await Chat.findByIdAndDelete(req.params.id);
    await Message.deleteMany({ chatId: req.params.id });
    res.json({ message: 'Chat deleted' });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/admin/bots
router.get('/bots', async (req, res) => {
  try {
    const bots = await Bot.find().populate('owner', 'username displayName').sort({ createdAt: -1 });
    res.json({ bots });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// PUT /api/admin/bots/:id/global
router.put('/bots/:id/global', async (req, res) => {
  try {
    const { isGlobal } = req.body;
    const bot = await Bot.findByIdAndUpdate(req.params.id, { isGlobal }, { new: true });
    if (!bot) return res.status(404).json({ error: 'Bot not found' });
    res.json({ bot, message: `Bot is now ${isGlobal ? 'global' : 'private'}` });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /api/admin/bots/seed - create default AI bots
router.post('/bots/seed', async (req, res) => {
  try {
    const defaultBots = [
      {
        name: 'Помощник',
        username: 'assistant_bot',
        description: 'Умный помощник на базе Groq AI. Отвечает на вопросы и помогает с задачами.',
        apiType: 'groq',
        model: 'llama3-8b-8192',
        systemPrompt: 'You are a helpful assistant. Answer questions clearly and concisely. Respond in the same language the user writes in.',
        capabilities: { stories: true, games: false },
        commands: [
          { command: '/help', description: 'Показать помощь', handler: 'help' },
          { command: '/story', description: 'Сгенерировать историю', handler: 'story' },
        ],
        triggers: ['помоги', 'помощь', 'help', 'привет'],
        isGlobal: true,
      },
      {
        name: 'Игровой Бот',
        username: 'game_bot',
        description: 'Бот для мини-игр: загадки, викторины, истории.',
        apiType: 'groq',
        model: 'llama3-8b-8192',
        systemPrompt: 'You are a fun game master. Create engaging riddles, trivia questions, and mini adventures. Keep responses short and fun. Use emoji. Respond in Russian by default.',
        capabilities: { stories: true, games: true },
        commands: [
          { command: '/riddle', description: 'Загадка', handler: 'riddle' },
          { command: '/trivia', description: 'Викторина', handler: 'trivia' },
          { command: '/adventure', description: 'Мини-приключение', handler: 'adventure' },
        ],
        triggers: ['игра', 'загадка', 'играть', 'game', 'riddle'],
        isGlobal: true,
      },
    ];

    const created = [];
    for (const botData of defaultBots) {
      const exists = await Bot.findOne({ username: botData.username });
      if (!exists) {
        const bot = await Bot.create({ ...botData, owner: null });
        created.push(bot.name);
      }
    }

    res.json({ message: `Created ${created.length} bots: ${created.join(', ')}` });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
