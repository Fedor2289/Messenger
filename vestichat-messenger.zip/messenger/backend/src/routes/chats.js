const express = require('express');
const { v4: uuidv4 } = require('uuid');
const Chat = require('../models/Chat');
const User = require('../models/User');
const Message = require('../models/Message');
const { auth } = require('../middleware/auth');

const router = express.Router();

// GET /api/chats - get user's chats
router.get('/', auth, async (req, res) => {
  try {
    const chats = await Chat.find({ 'members.user': req.user._id })
      .populate('members.user', 'username displayName avatar status lastSeen')
      .populate('lastMessage')
      .populate('bots', 'name username avatar')
      .sort({ lastActivity: -1 });

    res.json({ chats });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /api/chats - create chat
router.post('/', auth, async (req, res) => {
  try {
    const { type, name, description, memberIds, isPublic } = req.body;

    if (!type || !['direct', 'group', 'channel'].includes(type)) {
      return res.status(400).json({ error: 'Invalid chat type' });
    }

    let members = [{ user: req.user._id, role: 'owner' }];

    if (type === 'direct') {
      if (!memberIds || memberIds.length !== 1) {
        return res.status(400).json({ error: 'Direct chat requires exactly 1 other user' });
      }

      // Check if direct chat already exists
      const existing = await Chat.findOne({
        type: 'direct',
        'members.user': { $all: [req.user._id, memberIds[0]] },
        $expr: { $eq: [{ $size: '$members' }, 2] },
      });

      if (existing) {
        await existing.populate('members.user', 'username displayName avatar status lastSeen');
        return res.json({ chat: existing, existing: true });
      }

      const otherUser = await User.findById(memberIds[0]);
      if (!otherUser) return res.status(404).json({ error: 'User not found' });
      members.push({ user: memberIds[0], role: 'member' });
    } else {
      if (!name || name.trim().length < 1) {
        return res.status(400).json({ error: 'Name is required for group/channel' });
      }
      if (memberIds && memberIds.length > 0) {
        const validUsers = await User.find({ _id: { $in: memberIds }, isActive: true });
        validUsers.forEach(u => {
          if (u._id.toString() !== req.user._id.toString()) {
            members.push({ user: u._id, role: 'member' });
          }
        });
      }
    }

    const chat = await Chat.create({
      type,
      name: type === 'direct' ? null : name.trim(),
      description: description || '',
      members,
      isPublic: isPublic || false,
      inviteLink: type !== 'direct' ? uuidv4() : null,
    });

    await chat.populate('members.user', 'username displayName avatar status lastSeen');
    await chat.populate('bots', 'name username avatar');

    // Create system message
    if (type !== 'direct') {
      await Message.create({
        chatId: chat._id,
        type: 'system',
        content: `${req.user.displayName} created this ${type}`,
      });
    }

    res.status(201).json({ chat });
  } catch (error) {
    console.error('Create chat error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/chats/:id
router.get('/:id', auth, async (req, res) => {
  try {
    const chat = await Chat.findOne({
      _id: req.params.id,
      'members.user': req.user._id,
    })
      .populate('members.user', 'username displayName avatar status lastSeen')
      .populate('bots', 'name username avatar description commands')
      .populate('pinnedMessages');

    if (!chat) return res.status(404).json({ error: 'Chat not found' });
    res.json({ chat });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// PUT /api/chats/:id - update chat info
router.put('/:id', auth, async (req, res) => {
  try {
    const chat = await Chat.findById(req.params.id);
    if (!chat) return res.status(404).json({ error: 'Chat not found' });

    const member = chat.members.find(m => m.user.toString() === req.user._id.toString());
    if (!member || !['owner', 'admin'].includes(member.role)) {
      return res.status(403).json({ error: 'Not authorized' });
    }

    const { name, description, avatar, isPublic, settings } = req.body;
    const updates = {};
    if (name !== undefined) updates.name = name;
    if (description !== undefined) updates.description = description;
    if (avatar !== undefined) updates.avatar = avatar;
    if (isPublic !== undefined) updates.isPublic = isPublic;
    if (settings !== undefined) updates.settings = { ...chat.settings, ...settings };

    const updated = await Chat.findByIdAndUpdate(
      req.params.id,
      { $set: updates },
      { new: true }
    )
      .populate('members.user', 'username displayName avatar status lastSeen')
      .populate('bots', 'name username avatar');

    res.json({ chat: updated });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /api/chats/:id/members - add member
router.post('/:id/members', auth, async (req, res) => {
  try {
    const { userId } = req.body;
    const chat = await Chat.findById(req.params.id);
    if (!chat) return res.status(404).json({ error: 'Chat not found' });

    const requester = chat.members.find(m => m.user.toString() === req.user._id.toString());
    if (!requester || !['owner', 'admin'].includes(requester.role)) {
      return res.status(403).json({ error: 'Not authorized' });
    }

    const alreadyMember = chat.members.find(m => m.user.toString() === userId);
    if (alreadyMember) return res.status(409).json({ error: 'User already in chat' });

    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ error: 'User not found' });

    chat.members.push({ user: userId, role: 'member' });
    chat.lastActivity = new Date();
    await chat.save();

    await Message.create({
      chatId: chat._id,
      type: 'system',
      content: `${user.displayName} was added to the group`,
    });

    const io = req.app.get('io');
    if (io) {
      io.to(req.params.id).emit('member_added', { userId, chatId: req.params.id });
    }

    await chat.populate('members.user', 'username displayName avatar status lastSeen');
    res.json({ chat, message: 'Member added' });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// DELETE /api/chats/:id/members/:userId - remove member
router.delete('/:id/members/:userId', auth, async (req, res) => {
  try {
    const chat = await Chat.findById(req.params.id);
    if (!chat) return res.status(404).json({ error: 'Chat not found' });

    const isLeavingSelf = req.params.userId === req.user._id.toString();
    const requester = chat.members.find(m => m.user.toString() === req.user._id.toString());

    if (!isLeavingSelf && (!requester || !['owner', 'admin'].includes(requester.role))) {
      return res.status(403).json({ error: 'Not authorized' });
    }

    chat.members = chat.members.filter(m => m.user.toString() !== req.params.userId);
    chat.lastActivity = new Date();
    await chat.save();

    const user = await User.findById(req.params.userId);
    await Message.create({
      chatId: chat._id,
      type: 'system',
      content: isLeavingSelf
        ? `${req.user.displayName} left the group`
        : `${user?.displayName || 'User'} was removed`,
    });

    res.json({ message: 'Member removed' });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /api/chats/:id/bots - add bot to chat
router.post('/:id/bots', auth, async (req, res) => {
  try {
    const { botId } = req.body;
    const chat = await Chat.findById(req.params.id);
    if (!chat) return res.status(404).json({ error: 'Chat not found' });

    if (!chat.bots.includes(botId)) {
      chat.bots.push(botId);
      await chat.save();
    }
    await chat.populate('bots', 'name username avatar description');
    res.json({ chat, message: 'Bot added' });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// DELETE /api/chats/:id/bots/:botId - remove bot
router.delete('/:id/bots/:botId', auth, async (req, res) => {
  try {
    const chat = await Chat.findById(req.params.id);
    if (!chat) return res.status(404).json({ error: 'Chat not found' });
    chat.bots = chat.bots.filter(b => b.toString() !== req.params.botId);
    await chat.save();
    res.json({ message: 'Bot removed' });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/chats/public/list
router.get('/public/list', auth, async (req, res) => {
  try {
    const chats = await Chat.find({ isPublic: true, type: { $in: ['group', 'channel'] } })
      .populate('members.user', 'username displayName avatar')
      .select('name description avatar type members isPublic')
      .limit(50);
    res.json({ chats });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /api/chats/join/:inviteLink
router.post('/join/:inviteLink', auth, async (req, res) => {
  try {
    const chat = await Chat.findOne({ inviteLink: req.params.inviteLink });
    if (!chat) return res.status(404).json({ error: 'Invalid invite link' });

    const alreadyMember = chat.members.find(m => m.user.toString() === req.user._id.toString());
    if (alreadyMember) return res.json({ chat, message: 'Already a member' });

    chat.members.push({ user: req.user._id, role: 'member' });
    await chat.save();
    await chat.populate('members.user', 'username displayName avatar status lastSeen');

    res.json({ chat, message: 'Joined successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
