import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import toast from 'react-hot-toast';
import { MessageCircle, Eye, EyeOff } from 'lucide-react';

export default function RegisterPage() {
  const { register } = useAuth();
  const [form, setForm]   = useState({ username: '', email: '', password: '', displayName: '' });
  const [loading, setLoading] = useState(false);
  const [showPwd, setShowPwd] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.username || !form.email || !form.password) {
      toast.error('Заполните обязательные поля');
      return;
    }
    if (form.password.length < 6) {
      toast.error('Пароль минимум 6 символов');
      return;
    }
    setLoading(true);
    try {
      await register(form.username, form.email, form.password, form.displayName || form.username);
      toast.success('Аккаунт создан!');
    } catch (err) {
      toast.error(err.response?.data?.error || 'Ошибка регистрации');
    } finally {
      setLoading(false);
    }
  };

  const set = (key) => (e) => setForm(p => ({ ...p, [key]: e.target.value }));

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 via-white to-emerald-50 flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        <div className="flex flex-col items-center mb-8">
          <div className="w-16 h-16 bg-primary-500 rounded-2xl flex items-center justify-center mb-3 shadow-lg shadow-primary-200">
            <MessageCircle size={32} className="text-white" />
          </div>
          <h1 className="text-2xl font-bold text-slate-800">ВестиЧат</h1>
          <p className="text-slate-500 text-sm mt-1">Создайте аккаунт бесплатно</p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl shadow-slate-100 border border-slate-100 p-6">
          <h2 className="text-lg font-semibold text-slate-800 mb-5">Регистрация</h2>
          <form onSubmit={handleSubmit} className="flex flex-col gap-3.5">
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">
                Имя пользователя <span className="text-red-400">*</span>
              </label>
              <input className="input-field" placeholder="username" value={form.username} onChange={set('username')} />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Отображаемое имя</label>
              <input className="input-field" placeholder="Иван Иванов" value={form.displayName} onChange={set('displayName')} />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">
                Email <span className="text-red-400">*</span>
              </label>
              <input className="input-field" type="email" placeholder="you@example.com" value={form.email} onChange={set('email')} />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">
                Пароль <span className="text-red-400">*</span>
              </label>
              <div className="relative">
                <input
                  className="input-field pr-10"
                  type={showPwd ? 'text' : 'password'}
                  placeholder="Минимум 6 символов"
                  value={form.password}
                  onChange={set('password')}
                />
                <button type="button" onClick={() => setShowPwd(v => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                  {showPwd ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>
            <button type="submit" disabled={loading}
              className="btn-primary w-full mt-1 flex items-center justify-center gap-2 py-3">
              {loading ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : 'Создать аккаунт'}
            </button>
          </form>
        </div>

        <p className="text-center text-sm text-slate-500 mt-5">
          Уже есть аккаунт?{' '}
          <Link to="/login" className="text-primary-600 font-medium hover:underline">Войти</Link>
        </p>
      </div>
    </div>
  );
}
