import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { getSocket } from '../services/socket';
import { chatsAPI } from '../services/api';
import Sidebar from '../components/chat/Sidebar';
import ChatWindow from '../components/chat/ChatWindow';
import WelcomeScreen from '../components/chat/WelcomeScreen';
import ProfileModal from '../components/chat/ProfileModal';
import NewChatModal from '../components/chat/NewChatModal';
import toast from 'react-hot-toast';

export default function MessengerPage() {
  const { user, logout } = useAuth();
  const [chats, setChats]           = useState([]);
  const [activeChat, setActiveChat] = useState(null);
  const [loadingChats, setLoadingChats] = useState(true);
  const [showProfile, setShowProfile]   = useState(false);
  const [showNewChat, setShowNewChat]   = useState(false);
  const [mobileView, setMobileView]     = useState('sidebar'); // 'sidebar' | 'chat'
  const socketRef = useRef(null);

  // Load chats
  const loadChats = useCallback(async () => {
    try {
      const { data } = await chatsAPI.getAll();
      setChats(data.chats || []);
    } catch {
      toast.error('Не удалось загрузить чаты');
    } finally {
      setLoadingChats(false);
    }
  }, []);

  useEffect(() => { loadChats(); }, [loadChats]);

  // Socket events
  useEffect(() => {
    const socket = getSocket();
    if (!socket) return;
    socketRef.current = socket;

    const onNewMessage = ({ message, chatId }) => {
      setChats(prev => prev.map(c =>
        c._id === chatId
          ? { ...c, lastMessage: message, lastActivity: new Date().toISOString() }
          : c
      ).sort((a, b) => new Date(b.lastActivity) - new Date(a.lastActivity)));
    };

    const onUserStatus = ({ userId, status }) => {
      setChats(prev => prev.map(c => ({
        ...c,
        members: c.members?.map(m =>
          m.user?._id === userId ? { ...m, user: { ...m.user, status } } : m
        ),
      })));
    };

    socket.on('new_message', onNewMessage);
    socket.on('user_status', onUserStatus);

    return () => {
      socket.off('new_message', onNewMessage);
      socket.off('user_status', onUserStatus);
    };
  }, []);

  const selectChat = useCallback((chat) => {
    setActiveChat(chat);
    setMobileView('chat');
  }, []);

  const handleChatCreated = useCallback((chat) => {
    setChats(prev => {
      const exists = prev.find(c => c._id === chat._id);
      if (exists) return prev;
      return [chat, ...prev];
    });
    selectChat(chat);
    setShowNewChat(false);
  }, [selectChat]);

  const handleBack = () => {
    setMobileView('sidebar');
    setActiveChat(null);
  };

  return (
    <div className="h-screen flex bg-slate-50 overflow-hidden">
      {/* Sidebar */}
      <div className={`
        flex-shrink-0 w-full md:w-80 lg:w-96 h-full
        ${mobileView === 'chat' ? 'hidden md:flex' : 'flex'}
        flex-col bg-white border-r border-slate-100
      `}>
        <Sidebar
          user={user}
          chats={chats}
          activeChat={activeChat}
          loading={loadingChats}
          onSelectChat={selectChat}
          onNewChat={() => setShowNewChat(true)}
          onProfile={() => setShowProfile(true)}
          onLogout={logout}
          onChatsUpdate={loadChats}
        />
      </div>

      {/* Chat area */}
      <div className={`
        flex-1 h-full overflow-hidden
        ${mobileView === 'sidebar' ? 'hidden md:flex' : 'flex'}
        flex-col
      `}>
        {activeChat ? (
          <ChatWindow
            chat={activeChat}
            currentUser={user}
            onBack={handleBack}
            onChatUpdated={(updated) => {
              setActiveChat(updated);
              setChats(prev => prev.map(c => c._id === updated._id ? updated : c));
            }}
          />
        ) : (
          <WelcomeScreen onNewChat={() => setShowNewChat(true)} />
        )}
      </div>

      {/* Modals */}
      {showProfile && (
        <ProfileModal onClose={() => setShowProfile(false)} />
      )}
      {showNewChat && (
        <NewChatModal
          onClose={() => setShowNewChat(false)}
          onCreated={handleChatCreated}
        />
      )}
    </div>
  );
}
