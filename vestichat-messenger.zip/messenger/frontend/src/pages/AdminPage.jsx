import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowLeft, Users, MessageCircle, Bot, BarChart2,
  Trash2, Shield, ShieldOff, Globe, Lock, RefreshCw,
  Search, CheckCircle, XCircle, Zap,
} from 'lucide-react';
import { adminAPI } from '../services/api';
import { useAuth } from '../contexts/AuthContext';
import Avatar from '../components/ui/Avatar';
import toast from 'react-hot-toast';

export default function AdminPage() {
  const { user } = useAuth();
  const [tab, setTab]     = useState('stats');
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [chats, setChats] = useState([]);
  const [bots,  setBots]  = useState([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch]   = useState('');

  useEffect(() => { loadStats(); }, []);
  useEffect(() => {
    if (tab === 'users') loadUsers();
    if (tab === 'chats') loadChats();
    if (tab === 'bots')  loadBots();
  }, [tab]);

  const loadStats = async () => {
    try {
      const { data } = await adminAPI.getStats();
      setStats(data.stats);
    } catch { toast.error('Ошибка загрузки статистики'); }
  };

  const loadUsers = async () => {
    setLoading(true);
    try {
      const { data } = await adminAPI.getUsers({ search });
      setUsers(data.users || []);
    } catch { toast.error('Ошибка'); }
    finally { setLoading(false); }
  };

  const loadChats = async () => {
    setLoading(true);
    try {
      const { data } = await adminAPI.getChats();
      setChats(data.chats || []);
    } catch { toast.error('Ошибка'); }
    finally { setLoading(false); }
  };

  const loadBots = async () => {
    setLoading(true);
    try {
      const { data } = await adminAPI.getBots();
      setBots(data.bots || []);
    } catch { toast.error('Ошибка'); }
    finally { setLoading(false); }
  };

  const toggleUserRole = async (u) => {
    const newRole = u.role === 'admin' ? 'user' : 'admin';
    try {
      const { data } = await adminAPI.updateUser(u._id, { role: newRole });
      setUsers(prev => prev.map(x => x._id === u._id ? data.user : x));
      toast.success(`Роль изменена на ${newRole}`);
    } catch { toast.error('Ошибка'); }
  };

  const toggleUserActive = async (u) => {
    try {
      const { data } = await adminAPI.updateUser(u._id, { isActive: !u.isActive });
      setUsers(prev => prev.map(x => x._id === u._id ? data.user : x));
      toast.success(data.user.isActive ? 'Пользователь активирован' : 'Пользователь заблокирован');
    } catch { toast.error('Ошибка'); }
  };

  const deleteChat = async (id) => {
    if (!confirm('Удалить чат и все сообщения?')) return;
    try {
      await adminAPI.deleteChat(id);
      setChats(prev => prev.filter(c => c._id !== id));
      toast.success('Чат удалён');
    } catch { toast.error('Ошибка'); }
  };

  const toggleBotGlobal = async (bot) => {
    try {
      const { data } = await adminAPI.setBotGlobal(bot._id, !bot.isGlobal);
      setBots(prev => prev.map(b => b._id === bot._id ? data.bot : b));
      toast.success(data.message);
    } catch { toast.error('Ошибка'); }
  };

  const seedBots = async () => {
    try {
      const { data } = await adminAPI.seedBots();
      toast.success(data.message || 'Боты созданы');
      loadBots();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Ошибка');
    }
  };

  const TABS = [
    { id: 'stats',  label: 'Статистика', icon: BarChart2 },
    { id: 'users',  label: 'Пользователи', icon: Users },
    { id: 'chats',  label: 'Чаты', icon: MessageCircle },
    { id: 'bots',   label: 'Боты', icon: Bot },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Top bar */}
      <div className="bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Link to="/" className="p-2 rounded-xl hover:bg-slate-100 text-slate-500 transition-colors">
            <ArrowLeft size={18} />
          </Link>
          <div className="w-8 h-8 bg-primary-500 rounded-xl flex items-center justify-center">
            <Shield size={16} className="text-white" />
          </div>
          <div>
            <h1 className="font-bold text-slate-800">Панель администратора</h1>
            <p className="text-xs text-slate-400">ВестиЧат</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Avatar src={user?.avatar} name={user?.displayName || user?.username} size="sm" />
          <span className="text-sm font-medium text-slate-700 hidden sm:block">{user?.displayName}</span>
        </div>
      </div>

      <div className="flex h-[calc(100vh-65px)]">
        {/* Side nav */}
        <div className="w-56 bg-white border-r border-slate-100 p-3 flex-shrink-0">
          <nav className="space-y-1">
            {TABS.map(({ id, label, icon: Icon }) => (
              <button key={id} onClick={() => setTab(id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all text-left ${
                  tab === id
                    ? 'bg-primary-50 text-primary-700'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-800'
                }`}>
                <Icon size={16} />
                {label}
              </button>
            ))}
          </nav>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {/* STATS */}
          {tab === 'stats' && stats && (
            <div>
              <h2 className="text-lg font-bold text-slate-800 mb-4">Обзор системы</h2>
              <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                {[
                  { label: 'Пользователей',  value: stats.users,    color: 'bg-blue-500',    icon: Users },
                  { label: 'Онлайн',         value: stats.online,   color: 'bg-green-500',   icon: Zap },
                  { label: 'Новых сегодня',  value: stats.newToday, color: 'bg-violet-500',  icon: Users },
                  { label: 'Чатов',          value: stats.chats,    color: 'bg-amber-500',   icon: MessageCircle },
                  { label: 'Сообщений',      value: stats.messages, color: 'bg-pink-500',    icon: MessageCircle },
                  { label: 'Ботов',          value: stats.bots,     color: 'bg-primary-500', icon: Bot },
                ].map(({ label, value, color, icon: Icon }) => (
                  <div key={label} className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
                    <div className="flex items-center justify-between mb-3">
                      <p className="text-sm text-slate-500">{label}</p>
                      <div className={`w-8 h-8 ${color} rounded-xl flex items-center justify-center`}>
                        <Icon size={14} className="text-white" />
                      </div>
                    </div>
                    <p className="text-2xl font-bold text-slate-800">{value?.toLocaleString()}</p>
                  </div>
                ))}
              </div>
              <div className="bg-white rounded-2xl p-5 border border-slate-100">
                <h3 className="font-semibold text-slate-700 mb-3">Быстрые действия</h3>
                <div className="flex flex-wrap gap-2">
                  <button onClick={seedBots}
                    className="btn-primary flex items-center gap-2 text-sm">
                    <Bot size={14} /> Создать ИИ-ботов
                  </button>
                  <button onClick={loadStats}
                    className="btn-ghost flex items-center gap-2 text-sm border border-slate-200">
                    <RefreshCw size={14} /> Обновить
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* USERS */}
          {tab === 'users' && (
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-bold text-slate-800">Пользователи</h2>
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input className="input-field pl-8 py-2 text-sm w-48"
                      placeholder="Поиск..."
                      value={search}
                      onChange={e => setSearch(e.target.value)}
                      onKeyDown={e => e.key === 'Enter' && loadUsers()}
                    />
                  </div>
                  <button onClick={loadUsers} className="btn-ghost border border-slate-200 py-2 text-sm">
                    <Search size={14} />
                  </button>
                </div>
              </div>

              <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-slate-100 text-xs font-semibold text-slate-500 uppercase tracking-wide">
                      <th className="text-left px-4 py-3">Пользователь</th>
                      <th className="text-left px-4 py-3 hidden md:table-cell">Email</th>
                      <th className="text-left px-4 py-3">Роль</th>
                      <th className="text-left px-4 py-3">Статус</th>
                      <th className="text-right px-4 py-3">Действия</th>
                    </tr>
                  </thead>
                  <tbody>
                    {loading ? (
                      <tr><td colSpan="5" className="text-center py-8 text-slate-400">Загрузка...</td></tr>
                    ) : users.map(u => (
                      <tr key={u._id} className="border-b border-slate-50 hover:bg-slate-50 transition-colors">
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <Avatar src={u.avatar} name={u.displayName || u.username} size="sm" />
                            <div>
                              <p className="font-medium text-slate-800">{u.displayName || u.username}</p>
                              <p className="text-xs text-slate-400">@{u.username}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-slate-500 hidden md:table-cell">{u.email}</td>
                        <td className="px-4 py-3">
                          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                            u.role === 'admin' ? 'bg-primary-100 text-primary-700' :
                            u.role === 'moderator' ? 'bg-violet-100 text-violet-700' :
                            'bg-slate-100 text-slate-600'
                          }`}>
                            {u.role === 'admin' ? 'Админ' : u.role === 'moderator' ? 'Модер' : 'Юзер'}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                            u.isActive ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                          }`}>
                            {u.isActive ? 'Активен' : 'Заблокирован'}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center justify-end gap-1">
                            {u._id !== user?._id && (
                              <>
                                <button onClick={() => toggleUserRole(u)} title="Сменить роль"
                                  className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-primary-600 transition-colors">
                                  <Shield size={14} />
                                </button>
                                <button onClick={() => toggleUserActive(u)} title={u.isActive ? 'Заблокировать' : 'Активировать'}
                                  className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-red-500 transition-colors">
                                  {u.isActive ? <XCircle size={14} /> : <CheckCircle size={14} />}
                                </button>
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* CHATS */}
          {tab === 'chats' && (
            <div>
              <h2 className="text-lg font-bold text-slate-800 mb-4">Все чаты</h2>
              <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-slate-100 text-xs font-semibold text-slate-500 uppercase tracking-wide">
                      <th className="text-left px-4 py-3">Чат</th>
                      <th className="text-left px-4 py-3">Тип</th>
                      <th className="text-left px-4 py-3 hidden md:table-cell">Участников</th>
                      <th className="text-right px-4 py-3">Действия</th>
                    </tr>
                  </thead>
                  <tbody>
                    {loading ? (
                      <tr><td colSpan="4" className="text-center py-8 text-slate-400">Загрузка...</td></tr>
                    ) : chats.map(c => (
                      <tr key={c._id} className="border-b border-slate-50 hover:bg-slate-50 transition-colors">
                        <td className="px-4 py-3">
                          <p className="font-medium text-slate-800">
                            {c.type === 'direct'
                              ? c.members?.map(m => m.user?.displayName || m.user?.username).filter(Boolean).join(' & ')
                              : c.name || 'Без названия'}
                          </p>
                        </td>
                        <td className="px-4 py-3">
                          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                            c.type === 'direct' ? 'bg-blue-100 text-blue-700' :
                            c.type === 'group' ? 'bg-violet-100 text-violet-700' :
                            'bg-amber-100 text-amber-700'
                          }`}>
                            {c.type === 'direct' ? 'Личный' : c.type === 'group' ? 'Группа' : 'Канал'}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-slate-500 hidden md:table-cell">{c.members?.length || 0}</td>
                        <td className="px-4 py-3 text-right">
                          <button onClick={() => deleteChat(c._id)}
                            className="p-1.5 rounded-lg hover:bg-red-50 text-slate-400 hover:text-red-500 transition-colors">
                            <Trash2 size={14} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* BOTS */}
          {tab === 'bots' && (
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-bold text-slate-800">Управление ботами</h2>
                <button onClick={seedBots}
                  className="btn-primary flex items-center gap-2 text-sm">
                  <Zap size={14} /> Создать стандартных ботов
                </button>
              </div>
              <div className="grid gap-3">
                {loading ? (
                  <p className="text-slate-400 text-center py-8">Загрузка...</p>
                ) : bots.length === 0 ? (
                  <div className="bg-white rounded-2xl border border-slate-100 p-8 text-center">
                    <Bot size={40} className="mx-auto text-slate-300 mb-3" />
                    <p className="text-slate-500 mb-3">Ботов нет</p>
                    <button onClick={seedBots} className="btn-primary text-sm">
                      Создать стандартных ботов
                    </button>
                  </div>
                ) : bots.map(bot => (
                  <div key={bot._id} className="bg-white rounded-2xl border border-slate-100 p-4 flex items-center gap-4">
                    <div className="w-10 h-10 bg-primary-500 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Bot size={20} className="text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-semibold text-slate-800">{bot.name}</p>
                        <span className="text-xs text-slate-400">@{bot.username}</span>
                        {bot.isGlobal && (
                          <span className="text-xs bg-primary-100 text-primary-700 px-2 py-0.5 rounded-full font-medium">
                            Глобальный
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-500 truncate mt-0.5">{bot.description}</p>
                      <p className="text-xs text-slate-400 mt-0.5">
                        API: {bot.apiType} • Модель: {bot.model}
                        {bot.owner && ` • Создан: ${bot.owner.displayName || bot.owner.username}`}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <button onClick={() => toggleBotGlobal(bot)}
                        title={bot.isGlobal ? 'Сделать приватным' : 'Сделать глобальным'}
                        className={`p-2 rounded-xl transition-colors ${
                          bot.isGlobal
                            ? 'bg-primary-50 text-primary-600 hover:bg-primary-100'
                            : 'text-slate-400 hover:bg-slate-100 hover:text-slate-600'
                        }`}>
                        {bot.isGlobal ? <Globe size={16} /> : <Lock size={16} />}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
