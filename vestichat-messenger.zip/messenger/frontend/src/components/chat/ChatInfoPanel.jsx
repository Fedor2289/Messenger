import React, { useState, useEffect } from 'react';
import { X, Bot, UserPlus, Trash2, Settings, Copy, Check } from 'lucide-react';
import { botsAPI, usersAPI, chatsAPI } from '../../services/api';
import Avatar from '../ui/Avatar';
import toast from 'react-hot-toast';

export default function ChatInfoPanel({ chat, currentUser, onClose, onChatUpdated }) {
  const [bots, setBots]       = useState([]);
  const [loading, setLoading] = useState(false);
  const [tab, setTab]         = useState('info'); // 'info' | 'bots' | 'members'
  const [copied, setCopied]   = useState(false);

  const myRole = chat.members?.find(m => m.user?._id === currentUser._id)?.role;
  const isAdmin = ['owner', 'admin'].includes(myRole);

  useEffect(() => {
    if (tab === 'bots') {
      botsAPI.getAll()
        .then(({ data }) => setBots(data.bots || []))
        .catch(() => {});
    }
  }, [tab]);

  const addBot = async (botId) => {
    setLoading(true);
    try {
      const { data } = await chatsAPI.addBot(chat._id, botId);
      onChatUpdated(data.chat);
      toast.success('Бот добавлен в чат!');
    } catch (err) {
      toast.error(err.response?.data?.error || 'Ошибка');
    } finally {
      setLoading(false);
    }
  };

  const removeBot = async (botId) => {
    try {
      await chatsAPI.removeBot(chat._id, botId);
      onChatUpdated({ ...chat, bots: chat.bots.filter(b => b._id !== botId) });
      toast.success('Бот удалён из чата');
    } catch {
      toast.error('Ошибка');
    }
  };

  const copyInviteLink = () => {
    const link = `${window.location.origin}/join/${chat.inviteLink}`;
    navigator.clipboard.writeText(link);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast.success('Ссылка скопирована');
  };

  const chatBotIds = chat.bots?.map(b => b._id || b) || [];

  return (
    <div className="absolute inset-0 z-30 flex justify-end md:relative md:inset-auto md:w-80 md:border-l md:border-slate-100">
      {/* Backdrop on mobile */}
      <div className="absolute inset-0 bg-black/20 md:hidden" onClick={onClose} />

      <div className="relative z-10 w-80 bg-white h-full flex flex-col shadow-xl">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-4 border-b border-slate-100">
          <h3 className="font-semibold text-slate-800">Информация</h3>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-500">
            <X size={18} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-100">
          {['info', 'members', 'bots'].map(t => (
            <button key={t}
              onClick={() => setTab(t)}
              className={`flex-1 text-xs font-medium py-2.5 transition-colors border-b-2 ${
                tab === t ? 'border-primary-500 text-primary-600' : 'border-transparent text-slate-500 hover:text-slate-700'
              }`}
            >
              {t === 'info' ? 'Инфо' : t === 'members' ? 'Участники' : 'Боты'}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto scrollbar-thin p-4">
          {/* INFO TAB */}
          {tab === 'info' && (
            <div className="space-y-4">
              <div className="flex flex-col items-center py-4">
                <Avatar
                  src={chat.type === 'direct'
                    ? chat.members?.find(m => m.user?._id !== currentUser._id)?.user?.avatar
                    : chat.avatar}
                  name={chat.name || 'Chat'}
                  size="xl"
                />
                <h3 className="mt-3 font-bold text-slate-800">
                  {chat.type === 'direct'
                    ? chat.members?.find(m => m.user?._id !== currentUser._id)?.user?.displayName
                    : chat.name}
                </h3>
                {chat.description && (
                  <p className="text-sm text-slate-500 text-center mt-1">{chat.description}</p>
                )}
                <span className={`mt-2 text-xs px-2 py-0.5 rounded-full font-medium ${
                  chat.type === 'direct' ? 'bg-blue-50 text-blue-600' :
                  chat.type === 'group' ? 'bg-violet-50 text-violet-600' :
                  'bg-amber-50 text-amber-600'
                }`}>
                  {chat.type === 'direct' ? 'Личный чат' : chat.type === 'group' ? 'Группа' : 'Канал'}
                </span>
              </div>

              {chat.type !== 'direct' && chat.inviteLink && isAdmin && (
                <div className="bg-slate-50 rounded-xl p-3">
                  <p className="text-xs font-medium text-slate-600 mb-2">Ссылка-приглашение</p>
                  <div className="flex items-center gap-2">
                    <p className="text-xs text-slate-500 truncate flex-1">
                      {window.location.origin}/join/{chat.inviteLink}
                    </p>
                    <button onClick={copyInviteLink}
                      className="text-primary-600 hover:text-primary-700 flex-shrink-0">
                      {copied ? <Check size={14} /> : <Copy size={14} />}
                    </button>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-2 text-center">
                <div className="bg-slate-50 rounded-xl p-3">
                  <p className="text-lg font-bold text-slate-800">{chat.members?.length || 0}</p>
                  <p className="text-xs text-slate-500">Участников</p>
                </div>
                <div className="bg-slate-50 rounded-xl p-3">
                  <p className="text-lg font-bold text-primary-600">{chat.bots?.length || 0}</p>
                  <p className="text-xs text-slate-500">Ботов</p>
                </div>
              </div>
            </div>
          )}

          {/* MEMBERS TAB */}
          {tab === 'members' && (
            <div className="space-y-1">
              {chat.members?.map(m => {
                if (!m.user) return null;
                return (
                  <div key={m.user._id} className="flex items-center gap-3 py-2 px-2 rounded-xl hover:bg-slate-50">
                    <div className="relative">
                      <Avatar src={m.user.avatar} name={m.user.displayName || m.user.username} size="sm" />
                      <span className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border-2 border-white ${
                        m.user.status === 'online' ? 'bg-green-400' : 'bg-slate-300'
                      }`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-slate-800 truncate">
                        {m.user.displayName || m.user.username}
                      </p>
                      <p className="text-xs text-slate-400">@{m.user.username}</p>
                    </div>
                    {m.role !== 'member' && (
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                        m.role === 'owner' ? 'bg-amber-100 text-amber-700' : 'bg-primary-100 text-primary-700'
                      }`}>
                        {m.role === 'owner' ? 'Владелец' : 'Админ'}
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* BOTS TAB */}
          {tab === 'bots' && (
            <div className="space-y-3">
              {/* Active bots in chat */}
              {chat.bots?.length > 0 && (
                <div>
                  <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">В этом чате</p>
                  {chat.bots.map(bot => (
                    <div key={bot._id || bot} className="flex items-center gap-3 p-2.5 bg-primary-50 rounded-xl mb-1.5">
                      <div className="w-8 h-8 bg-primary-500 rounded-xl flex items-center justify-center flex-shrink-0">
                        <Bot size={16} className="text-white" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-slate-800 truncate">{bot.name || 'Бот'}</p>
                        <p className="text-xs text-slate-500 truncate">@{bot.username || '...'}</p>
                      </div>
                      {isAdmin && (
                        <button onClick={() => removeBot(bot._id || bot)}
                          className="text-red-400 hover:text-red-600 p-1">
                          <X size={14} />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {/* Available bots */}
              {isAdmin && (
                <div>
                  <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Добавить бота</p>
                  {bots.filter(b => !chatBotIds.includes(b._id)).length === 0 ? (
                    <p className="text-sm text-slate-400 text-center py-4">Все доступные боты уже добавлены</p>
                  ) : (
                    bots.filter(b => !chatBotIds.includes(b._id)).map(bot => (
                      <div key={bot._id} className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-slate-50 mb-1">
                        <div className="w-8 h-8 bg-slate-200 rounded-xl flex items-center justify-center flex-shrink-0">
                          <Bot size={16} className="text-slate-500" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-slate-800 truncate">{bot.name}</p>
                          <p className="text-xs text-slate-400 truncate">{bot.description?.slice(0, 40) || `@${bot.username}`}</p>
                        </div>
                        <button
                          onClick={() => addBot(bot._id)}
                          disabled={loading}
                          className="text-xs btn-primary py-1 px-2.5"
                        >
                          + Добавить
                        </button>
                      </div>
                    ))
                  )}
                </div>
              )}

              <p className="text-xs text-slate-400 text-center pt-2">
                Упомяните бота через @username или используйте команды /story, /riddle, /help
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
