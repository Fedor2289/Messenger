import React, { useState, useRef } from 'react';
import { X, Camera, Save, Lock } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { authAPI, filesAPI } from '../../services/api';
import Avatar from '../ui/Avatar';
import toast from 'react-hot-toast';

export default function ProfileModal({ onClose }) {
  const { user, updateUser } = useAuth();
  const [tab, setTab]   = useState('profile'); // 'profile' | 'password'
  const [form, setForm] = useState({
    displayName: user?.displayName || '',
    bio: user?.bio || '',
    avatar: user?.avatar || '',
  });
  const [pwdForm, setPwdForm] = useState({ currentPassword: '', newPassword: '', confirm: '' });
  const [loading, setLoading] = useState(false);
  const fileRef = useRef(null);

  const set = (k) => (e) => setForm(p => ({ ...p, [k]: e.target.value }));
  const setPwd = (k) => (e) => setPwdForm(p => ({ ...p, [k]: e.target.value }));

  const handleAvatarUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setLoading(true);
    try {
      const { data } = await filesAPI.uploadAvatar(file);
      setForm(p => ({ ...p, avatar: data.url }));
      toast.success('Фото загружено');
    } catch {
      toast.error('Ошибка загрузки фото');
    } finally {
      setLoading(false);
    }
  };

  const saveProfile = async () => {
    setLoading(true);
    try {
      const { data } = await authAPI.updateProfile(form);
      updateUser(data.user);
      toast.success('Профиль обновлён');
      onClose();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Ошибка');
    } finally {
      setLoading(false);
    }
  };

  const changePassword = async () => {
    if (pwdForm.newPassword !== pwdForm.confirm) {
      toast.error('Пароли не совпадают');
      return;
    }
    if (pwdForm.newPassword.length < 6) {
      toast.error('Пароль минимум 6 символов');
      return;
    }
    setLoading(true);
    try {
      await authAPI.changePassword({
        currentPassword: pwdForm.currentPassword,
        newPassword: pwdForm.newPassword,
      });
      toast.success('Пароль изменён');
      setPwdForm({ currentPassword: '', newPassword: '', confirm: '' });
    } catch (err) {
      toast.error(err.response?.data?.error || 'Ошибка');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="relative z-10 w-full max-w-sm bg-white rounded-2xl shadow-2xl overflow-hidden animate-fade-up">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
          <h2 className="font-bold text-slate-800">Мой профиль</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-500">
            <X size={18} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-100">
          {[['profile','Профиль'], ['password','Пароль']].map(([t, l]) => (
            <button key={t} onClick={() => setTab(t)}
              className={`flex-1 text-sm font-medium py-3 border-b-2 transition-colors ${
                tab === t ? 'border-primary-500 text-primary-600' : 'border-transparent text-slate-500 hover:text-slate-700'
              }`}>
              {l}
            </button>
          ))}
        </div>

        <div className="p-5">
          {tab === 'profile' && (
            <div className="space-y-4">
              {/* Avatar */}
              <div className="flex justify-center">
                <div className="relative">
                  <Avatar src={form.avatar} name={form.displayName || user?.username} size="xl" />
                  <button
                    onClick={() => fileRef.current?.click()}
                    className="absolute bottom-0 right-0 w-8 h-8 bg-primary-500 rounded-full flex items-center justify-center text-white shadow-lg hover:bg-primary-600 transition-colors"
                  >
                    <Camera size={14} />
                  </button>
                  <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleAvatarUpload} />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1.5">Отображаемое имя</label>
                <input className="input-field" value={form.displayName} onChange={set('displayName')} placeholder="Ваше имя" />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1.5">О себе</label>
                <textarea
                  className="input-field resize-none"
                  rows={3}
                  value={form.bio}
                  onChange={set('bio')}
                  placeholder="Расскажите о себе..."
                  maxLength={200}
                />
                <p className="text-xs text-slate-400 text-right mt-1">{form.bio.length}/200</p>
              </div>

              <div className="bg-slate-50 rounded-xl p-3">
                <p className="text-xs text-slate-500">
                  <span className="font-medium">Username:</span> @{user?.username}
                </p>
                <p className="text-xs text-slate-500 mt-1">
                  <span className="font-medium">Email:</span> {user?.email}
                </p>
                <p className="text-xs text-slate-500 mt-1">
                  <span className="font-medium">Роль:</span>{' '}
                  <span className={user?.role === 'admin' ? 'text-primary-600 font-semibold' : ''}>
                    {user?.role === 'admin' ? '👑 Администратор' : user?.role === 'moderator' ? '🛡 Модератор' : '👤 Пользователь'}
                  </span>
                </p>
              </div>

              <button onClick={saveProfile} disabled={loading}
                className="btn-primary w-full flex items-center justify-center gap-2 py-3">
                {loading
                  ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  : <><Save size={15} /> Сохранить</>}
              </button>
            </div>
          )}

          {tab === 'password' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1.5">Текущий пароль</label>
                <input className="input-field" type="password" value={pwdForm.currentPassword}
                  onChange={setPwd('currentPassword')} placeholder="••••••" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1.5">Новый пароль</label>
                <input className="input-field" type="password" value={pwdForm.newPassword}
                  onChange={setPwd('newPassword')} placeholder="Минимум 6 символов" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1.5">Повторите новый пароль</label>
                <input className="input-field" type="password" value={pwdForm.confirm}
                  onChange={setPwd('confirm')} placeholder="••••••" />
              </div>
              <button onClick={changePassword} disabled={loading}
                className="btn-primary w-full flex items-center justify-center gap-2 py-3">
                {loading
                  ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  : <><Lock size={15} /> Изменить пароль</>}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
