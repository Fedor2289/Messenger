import React, { useState } from 'react';
import { format } from 'date-fns';
import { ru } from 'date-fns/locale';
import { Reply, Trash2, Bot, Check, CheckCheck } from 'lucide-react';
import Avatar from '../ui/Avatar';

const REACTIONS = ['👍', '❤️', '😂', '😮', '😢', '🔥'];

export default function MessageBubble({ message, currentUser, prevMessage, onReply, onDelete }) {
  const [showActions, setShowActions] = useState(false);
  const [showReactions, setShowReactions] = useState(false);

  const isSelf  = message.sender?._id === currentUser?._id;
  const isBot   = message.type === 'bot' || !!message.bot;
  const isSystem = message.type === 'system';

  // Group messages from same sender
  const sameAsPrev = prevMessage &&
    (prevMessage.sender?._id === message.sender?._id || prevMessage.bot?._id === message.bot?._id) &&
    !prevMessage.type?.includes('system') && !message.type?.includes('system') &&
    (new Date(message.createdAt) - new Date(prevMessage.createdAt)) < 5 * 60 * 1000;

  if (isSystem) {
    return (
      <div className="flex justify-center my-2">
        <span className="text-xs text-slate-400 bg-slate-100 px-3 py-1 rounded-full">
          {message.content}
        </span>
      </div>
    );
  }

  const senderName = isBot
    ? message.bot?.name || 'Бот'
    : message.sender?.displayName || message.sender?.username || 'Пользователь';

  const senderAvatar = isBot ? message.bot?.avatar : message.sender?.avatar;

  const timeStr = format(new Date(message.createdAt), 'HH:mm', { locale: ru });

  return (
    <div
      className={`flex gap-2 animate-fade-up group ${isSelf ? 'flex-row-reverse' : 'flex-row'} ${sameAsPrev ? 'mt-0.5' : 'mt-3'}`}
      onMouseEnter={() => setShowActions(true)}
      onMouseLeave={() => { setShowActions(false); setShowReactions(false); }}
    >
      {/* Avatar */}
      <div className={`w-8 flex-shrink-0 ${isSelf ? 'hidden' : ''}`}>
        {!sameAsPrev && (
          <Avatar src={senderAvatar} name={senderName} size="sm" />
        )}
      </div>

      <div className={`flex flex-col max-w-xs lg:max-w-md ${isSelf ? 'items-end' : 'items-start'}`}>
        {/* Sender name (for groups) */}
        {!sameAsPrev && !isSelf && (
          <div className="flex items-center gap-1 mb-1 px-1">
            <span className={`text-xs font-medium ${isBot ? 'text-primary-600' : 'text-slate-600'}`}>
              {senderName}
            </span>
            {isBot && <Bot size={11} className="text-primary-500" />}
          </div>
        )}

        {/* Reply preview */}
        {message.replyTo && (
          <div className={`text-xs px-2.5 py-1.5 rounded-xl mb-1 border-l-2 border-primary-400 bg-slate-50 max-w-full`}>
            <p className="font-medium text-primary-600 truncate">
              {message.replyTo.sender?.displayName || 'Сообщение'}
            </p>
            <p className="text-slate-500 truncate">{message.replyTo.content}</p>
          </div>
        )}

        {/* Bubble */}
        <div className={`relative ${isSelf ? 'msg-bubble-self' : isBot ? 'msg-bubble-bot' : 'msg-bubble-other'}`}>
          {renderContent(message)}

          {/* Time + read status */}
          <div className={`flex items-center gap-1 mt-1 ${isSelf ? 'justify-end' : 'justify-start'}`}>
            {message.edited && <span className="text-[10px] opacity-60">ред.</span>}
            <span className={`text-[10px] ${isSelf ? 'text-green-100' : 'text-slate-400'}`}>{timeStr}</span>
            {isSelf && (
              message.readBy?.length > 1
                ? <CheckCheck size={12} className="text-green-200" />
                : <Check size={12} className="text-green-200" />
            )}
          </div>
        </div>

        {/* Reactions */}
        {message.reactions?.length > 0 && (
          <div className="flex flex-wrap gap-1 mt-1">
            {message.reactions.map(r => (
              <span key={r.emoji}
                className="text-xs bg-white border border-slate-200 rounded-full px-1.5 py-0.5 shadow-sm cursor-pointer hover:border-primary-300 transition-colors">
                {r.emoji} {r.users?.length > 1 && r.users.length}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Action buttons */}
      <div className={`flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity self-end mb-6
        ${isSelf ? 'flex-row-reverse mr-1' : 'ml-1'}`}>
        <button onClick={() => onReply(message)}
          className="p-1.5 rounded-lg bg-white shadow-sm text-slate-400 hover:text-primary-500 hover:shadow-md transition-all">
          <Reply size={13} />
        </button>
        <div className="relative">
          <button onClick={() => setShowReactions(v => !v)}
            className="p-1.5 rounded-lg bg-white shadow-sm text-slate-400 hover:text-yellow-500 hover:shadow-md transition-all">
            😊
          </button>
          {showReactions && (
            <div className={`absolute bottom-8 ${isSelf ? 'right-0' : 'left-0'} bg-white rounded-2xl shadow-lg border border-slate-100 px-2 py-1.5 flex gap-1.5 z-10 animate-fade-up`}>
              {REACTIONS.map(emoji => (
                <button key={emoji}
                  onClick={() => { setShowReactions(false); }}
                  className="text-lg hover:scale-125 transition-transform">{emoji}</button>
              ))}
            </div>
          )}
        </div>
        {isSelf && !message.deleted && (
          <button onClick={() => onDelete(message._id)}
            className="p-1.5 rounded-lg bg-white shadow-sm text-slate-400 hover:text-red-500 hover:shadow-md transition-all">
            <Trash2 size={13} />
          </button>
        )}
      </div>
    </div>
  );
}

function renderContent(message) {
  if (message.deleted) {
    return <span className="italic opacity-60 text-sm">Сообщение удалено</span>;
  }

  if (message.type === 'image' && message.attachment) {
    return (
      <div>
        <img
          src={message.attachment.url}
          alt={message.attachment.originalName || 'Изображение'}
          className="max-w-xs rounded-xl cursor-pointer hover:opacity-90 transition-opacity"
          onClick={() => window.open(message.attachment.url, '_blank')}
          onError={e => { e.target.style.display = 'none'; }}
        />
        {message.content && message.content !== message.attachment.originalName && (
          <p className="text-sm mt-1">{message.content}</p>
        )}
      </div>
    );
  }

  if (message.type === 'voice' && message.attachment) {
    return (
      <div className="flex items-center gap-2">
        <audio controls className="h-8 max-w-[200px]">
          <source src={message.attachment.url} type={message.attachment.mimeType} />
        </audio>
      </div>
    );
  }

  if (message.type === 'video' && message.attachment) {
    return (
      <video controls className="max-w-xs rounded-xl max-h-64">
        <source src={message.attachment.url} type={message.attachment.mimeType} />
      </video>
    );
  }

  if (message.type === 'file' && message.attachment) {
    const size = message.attachment.size
      ? message.attachment.size > 1024 * 1024
        ? `${(message.attachment.size / 1024 / 1024).toFixed(1)} МБ`
        : `${Math.round(message.attachment.size / 1024)} КБ`
      : '';
    return (
      <a
        href={message.attachment.url}
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-2 hover:opacity-80 transition-opacity"
      >
        <div className="w-8 h-8 bg-white bg-opacity-20 rounded-lg flex items-center justify-center text-base">
          📎
        </div>
        <div>
          <p className="text-sm font-medium truncate max-w-[160px]">{message.attachment.originalName}</p>
          {size && <p className="text-xs opacity-70">{size}</p>}
        </div>
      </a>
    );
  }

  // Text / bot message — preserve line breaks
  const text = message.content || '';
  return (
    <p className="text-sm whitespace-pre-wrap leading-relaxed">{text}</p>
  );
}
