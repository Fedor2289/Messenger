import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  ArrowLeft, Phone, Video, Info, Paperclip,
  Send, Smile, MoreVertical, Bot, X,
} from 'lucide-react';
import { messagesAPI, filesAPI } from '../../services/api';
import { getSocket } from '../../services/socket';
import Avatar from '../ui/Avatar';
import MessageBubble from './MessageBubble';
import ChatInfoPanel from './ChatInfoPanel';
import toast from 'react-hot-toast';

export default function ChatWindow({ chat, currentUser, onBack, onChatUpdated }) {
  const [messages, setMessages]     = useState([]);
  const [input, setInput]           = useState('');
  const [sending, setSending]       = useState(false);
  const [loading, setLoading]       = useState(true);
  const [typingUsers, setTypingUsers] = useState([]);
  const [showInfo, setShowInfo]     = useState(false);
  const [replyTo, setReplyTo]       = useState(null);
  const [uploadProgress, setUploadProgress] = useState(null);

  const bottomRef = useRef(null);
  const fileRef   = useRef(null);
  const inputRef  = useRef(null);
  const typingTimeout = useRef(null);

  // Load messages
  useEffect(() => {
    if (!chat?._id) return;
    setLoading(true);
    setMessages([]);
    setReplyTo(null);

    messagesAPI.getByChatId(chat._id)
      .then(({ data }) => setMessages(data.messages || []))
      .catch(() => toast.error('Не удалось загрузить сообщения'))
      .finally(() => setLoading(false));
  }, [chat._id]);

  // Socket events
  useEffect(() => {
    const socket = getSocket();
    if (!socket) return;

    socket.emit('join_chat', { chatId: chat._id });
    socket.emit('read_messages', { chatId: chat._id });

    const onNewMessage = ({ message, chatId }) => {
      if (chatId !== chat._id) return;
      setMessages(prev => {
        if (prev.find(m => m._id === message._id)) return prev;
        return [...prev, message];
      });
      socket.emit('read_messages', { chatId: chat._id });
    };

    const onTyping = ({ userId, username, chatId }) => {
      if (chatId !== chat._id || userId === currentUser._id) return;
      setTypingUsers(prev => prev.find(u => u.userId === userId) ? prev : [...prev, { userId, username }]);
    };

    const onStopTyping = ({ userId, chatId }) => {
      if (chatId !== chat._id) return;
      setTypingUsers(prev => prev.filter(u => u.userId !== userId));
    };

    const onEdited = ({ message }) => {
      setMessages(prev => prev.map(m => m._id === message._id ? message : m));
    };

    const onDeleted = ({ messageId }) => {
      setMessages(prev => prev.map(m =>
        m._id === messageId ? { ...m, deleted: true, content: 'Сообщение удалено' } : m
      ));
    };

    const onReaction = ({ messageId, reactions }) => {
      setMessages(prev => prev.map(m => m._id === messageId ? { ...m, reactions } : m));
    };

    socket.on('new_message', onNewMessage);
    socket.on('user_typing', onTyping);
    socket.on('user_stop_typing', onStopTyping);
    socket.on('message_edited', onEdited);
    socket.on('message_deleted', onDeleted);
    socket.on('message_reaction', onReaction);

    return () => {
      socket.off('new_message', onNewMessage);
      socket.off('user_typing', onTyping);
      socket.off('user_stop_typing', onStopTyping);
      socket.off('message_edited', onEdited);
      socket.off('message_deleted', onDeleted);
      socket.off('message_reaction', onReaction);
    };
  }, [chat._id, currentUser._id]);

  // Auto scroll to bottom
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, typingUsers]);

  // Handle typing
  const handleTyping = () => {
    const socket = getSocket();
    if (!socket) return;
    socket.emit('typing_start', { chatId: chat._id });
    clearTimeout(typingTimeout.current);
    typingTimeout.current = setTimeout(() => {
      socket.emit('typing_stop', { chatId: chat._id });
    }, 2000);
  };

  const sendMessage = useCallback(async () => {
    const content = input.trim();
    if (!content || sending) return;

    const socket = getSocket();
    setInput('');
    setReplyTo(null);
    setSending(true);

    try {
      if (socket?.connected) {
        socket.emit('send_message', {
          chatId: chat._id,
          content,
          type: 'text',
          replyTo: replyTo?._id || null,
        });
        socket.emit('typing_stop', { chatId: chat._id });
      } else {
        const { data } = await messagesAPI.send({
          chatId: chat._id, content, type: 'text',
          replyTo: replyTo?._id || null,
        });
        setMessages(prev => [...prev, data.message]);
      }
    } catch {
      toast.error('Не удалось отправить сообщение');
      setInput(content);
    } finally {
      setSending(false);
      inputRef.current?.focus();
    }
  }, [input, sending, chat._id, replyTo]);

  const handleKey = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 50 * 1024 * 1024) {
      toast.error('Файл не должен превышать 50 МБ');
      return;
    }

    setUploadProgress(0);
    try {
      await filesAPI.upload(chat._id, file, (e) => {
        setUploadProgress(Math.round(e.loaded / e.total * 100));
      });
      toast.success('Файл отправлен');
    } catch {
      toast.error('Ошибка загрузки файла');
    } finally {
      setUploadProgress(null);
      e.target.value = '';
    }
  };

  // Chat header info
  const chatName = getChatName(chat, currentUser);
  const chatAvatar = getChatAvatar(chat, currentUser);
  const onlineText = getOnlineText(chat, currentUser);

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 bg-white border-b border-slate-100 flex-shrink-0">
        <button onClick={onBack} className="md:hidden p-1.5 rounded-lg hover:bg-slate-100 text-slate-500">
          <ArrowLeft size={20} />
        </button>
        <div
          className="flex items-center gap-3 flex-1 cursor-pointer min-w-0"
          onClick={() => setShowInfo(true)}
        >
          <Avatar src={chatAvatar} name={chatName} size="md" />
          <div className="min-w-0">
            <p className="font-semibold text-slate-800 text-sm truncate">{chatName}</p>
            <p className="text-xs text-slate-400 truncate">{onlineText}</p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          {chat.bots?.length > 0 && (
            <div className="flex items-center gap-1 bg-primary-50 text-primary-600 text-xs px-2 py-1 rounded-full">
              <Bot size={12} />
              <span>{chat.bots.length} бот{chat.bots.length > 1 ? 'а' : ''}</span>
            </div>
          )}
          <button onClick={() => setShowInfo(true)}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors">
            <Info size={18} />
          </button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto scrollbar-thin px-4 py-4 space-y-1">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="w-8 h-8 border-3 border-primary-400 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-slate-400">
            <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mb-3">
              <Send size={24} className="opacity-40" />
            </div>
            <p className="text-sm font-medium">Нет сообщений</p>
            <p className="text-xs mt-1">Начните общение прямо сейчас!</p>
          </div>
        ) : (
          messages.map((msg, idx) => (
            <MessageBubble
              key={msg._id}
              message={msg}
              currentUser={currentUser}
              prevMessage={messages[idx - 1]}
              onReply={setReplyTo}
              onDelete={(id) => {
                const socket = getSocket();
                if (socket) socket.emit('delete_message', { messageId: id });
              }}
            />
          ))
        )}

        {/* Typing indicator */}
        {typingUsers.length > 0 && (
          <div className="flex items-center gap-2 animate-fade-up">
            <div className="bg-white rounded-2xl rounded-bl-sm shadow-sm px-4 py-2.5 flex items-center gap-2">
              <div className="flex gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-pulse-dot" />
                <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-pulse-dot" />
                <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-pulse-dot" />
              </div>
              <span className="text-xs text-slate-400">{typingUsers[0].username} печатает...</span>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Reply bar */}
      {replyTo && (
        <div className="flex items-center gap-3 px-4 py-2 bg-primary-50 border-t border-primary-100">
          <div className="flex-1 border-l-2 border-primary-400 pl-3">
            <p className="text-xs font-medium text-primary-600">
              {replyTo.sender?.displayName || replyTo.bot?.name || 'Сообщение'}
            </p>
            <p className="text-xs text-slate-500 truncate">{replyTo.content}</p>
          </div>
          <button onClick={() => setReplyTo(null)} className="text-slate-400 hover:text-slate-600">
            <X size={16} />
          </button>
        </div>
      )}

      {/* Upload progress */}
      {uploadProgress !== null && (
        <div className="px-4 py-2 bg-white border-t border-slate-100">
          <div className="flex items-center gap-2">
            <div className="flex-1 bg-slate-200 rounded-full h-1.5">
              <div className="bg-primary-500 h-1.5 rounded-full transition-all" style={{ width: `${uploadProgress}%` }} />
            </div>
            <span className="text-xs text-slate-500">{uploadProgress}%</span>
          </div>
        </div>
      )}

      {/* Input area */}
      <div className="flex items-end gap-2 px-4 py-3 bg-white border-t border-slate-100 flex-shrink-0">
        <input ref={fileRef} type="file" className="hidden" onChange={handleFileUpload}
          accept="image/*,video/*,audio/*,.pdf,.doc,.docx,.xls,.xlsx,.txt,.zip,.rar" />
        <button
          onClick={() => fileRef.current?.click()}
          className="p-2 rounded-xl text-slate-400 hover:text-primary-600 hover:bg-primary-50 transition-colors flex-shrink-0"
        >
          <Paperclip size={20} />
        </button>

        <div className="flex-1 relative">
          <textarea
            ref={inputRef}
            value={input}
            onChange={e => { setInput(e.target.value); handleTyping(); }}
            onKeyDown={handleKey}
            placeholder="Написать сообщение..."
            rows={1}
            className="w-full resize-none bg-slate-100 rounded-2xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300 focus:bg-white transition-all max-h-32 overflow-y-auto"
            style={{ minHeight: '42px' }}
          />
        </div>

        <button
          onClick={sendMessage}
          disabled={!input.trim() || sending}
          className="p-2.5 rounded-xl bg-primary-500 hover:bg-primary-600 text-white transition-all disabled:opacity-40 disabled:cursor-not-allowed flex-shrink-0"
        >
          <Send size={18} />
        </button>
      </div>

      {/* Chat info panel */}
      {showInfo && (
        <ChatInfoPanel
          chat={chat}
          currentUser={currentUser}
          onClose={() => setShowInfo(false)}
          onChatUpdated={onChatUpdated}
        />
      )}
    </div>
  );
}

function getChatName(chat, me) {
  if (chat.type === 'direct') {
    const other = chat.members?.find(m => m.user?._id !== me?._id);
    return other?.user?.displayName || other?.user?.username || 'Пользователь';
  }
  return chat.name || 'Без названия';
}

function getChatAvatar(chat, me) {
  if (chat.type === 'direct') {
    const other = chat.members?.find(m => m.user?._id !== me?._id);
    return other?.user?.avatar || null;
  }
  return chat.avatar || null;
}

function getOnlineText(chat, me) {
  if (chat.type === 'direct') {
    const other = chat.members?.find(m => m.user?._id !== me?._id);
    return other?.user?.status === 'online' ? '🟢 В сети' : '⚫ Не в сети';
  }
  const count = chat.members?.length || 0;
  const online = chat.members?.filter(m => m.user?.status === 'online').length || 0;
  if (chat.type === 'channel') return `${count} подписчиков`;
  return `${count} участников • ${online} онлайн`;
}
