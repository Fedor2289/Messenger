import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  MessageCircle, Plus, Search, Settings, LogOut,
  Shield, Users, Hash, Bot,
} from 'lucide-react';
import Avatar from '../ui/Avatar';
import { formatDistanceToNow } from 'date-fns';
import { ru } from 'date-fns/locale';

export default function Sidebar({
  user, chats, activeChat, loading,
  onSelectChat, onNewChat, onProfile, onLogout, onChatsUpdate,
}) {
  const [search, setSearch] = useState('');

  const filtered = chats.filter(c => {
    const name = getChatName(c, user);
    return name.toLowerCase().includes(search.toLowerCase());
  });

  function getChatName(chat, me) {
    if (chat.type === 'direct') {
      const other = chat.members?.find(m => m.user?._id !== me?._id);
      return other?.user?.displayName || other?.user?.username || 'Пользователь';
    }
    return chat.name || 'Без названия';
  }

  function getChatAvatar(chat, me) {
    if (chat.type === 'direct') {
      const other = chat.members?.find(m => m.user?._id !== me?._id);
      return other?.user?.avatar || null;
    }
    return chat.avatar || null;
  }

  function getStatusColor(chat, me) {
    if (chat.type === 'direct') {
      const other = chat.members?.find(m => m.user?._id !== me?._id);
      return other?.user?.status === 'online' ? 'bg-green-400' : 'bg-slate-300';
    }
    return null;
  }

  function getChatIcon(type) {
    if (type === 'group') return <Users size={12} />;
    if (type === 'channel') return <Hash size={12} />;
    return null;
  }

  function getLastMessagePreview(chat) {
    const lm = chat.lastMessage;
    if (!lm) return 'Нет сообщений';
    if (lm.type === 'image') return '🖼 Фото';
    if (lm.type === 'voice') return '🎵 Голосовое';
    if (lm.type === 'video') return '🎬 Видео';
    if (lm.type === 'file') return '📎 Файл';
    if (lm.type === 'bot')  return `🤖 ${lm.content?.slice(0, 40)}...`;
    if (lm.type === 'system') return lm.content;
    return lm.content?.slice(0, 50) || '';
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-4 border-b border-slate-100">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-primary-500 rounded-xl flex items-center justify-center">
            <MessageCircle size={16} className="text-white" />
          </div>
          <span className="font-bold text-slate-800 text-lg">ВестиЧат</span>
        </div>
        <div className="flex items-center gap-1">
          {user?.role === 'admin' && (
            <Link to="/admin" title="Панель администратора"
              className="p-2 rounded-xl text-slate-400 hover:text-primary-600 hover:bg-primary-50 transition-colors">
              <Shield size={18} />
            </Link>
          )}
          <button onClick={onNewChat} title="Новый чат"
            className="p-2 rounded-xl text-slate-400 hover:text-primary-600 hover:bg-primary-50 transition-colors">
            <Plus size={18} />
          </button>
          <button onClick={onLogout} title="Выйти"
            className="p-2 rounded-xl text-slate-400 hover:text-red-500 hover:bg-red-50 transition-colors">
            <LogOut size={18} />
          </button>
        </div>
      </div>

      {/* Search */}
      <div className="px-3 py-3">
        <div className="relative">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            className="w-full bg-slate-100 rounded-xl pl-8 pr-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300 focus:bg-white transition-all"
            placeholder="Поиск чатов..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
      </div>

      {/* Chat list */}
      <div className="flex-1 overflow-y-auto scrollbar-thin px-2 pb-2">
        {loading ? (
          <div className="flex flex-col gap-2 px-2 pt-2">
            {[1,2,3,4].map(i => (
              <div key={i} className="flex items-center gap-3 p-2 animate-pulse">
                <div className="w-12 h-12 rounded-full bg-slate-200 flex-shrink-0" />
                <div className="flex-1 space-y-2">
                  <div className="h-3 bg-slate-200 rounded w-3/4" />
                  <div className="h-2.5 bg-slate-200 rounded w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-slate-400">
            <MessageCircle size={36} className="mb-2 opacity-30" />
            <p className="text-sm">{search ? 'Чатов не найдено' : 'Нет чатов'}</p>
            {!search && (
              <button onClick={onNewChat}
                className="mt-3 text-xs text-primary-600 font-medium hover:underline">
                Начать первый чат
              </button>
            )}
          </div>
        ) : (
          filtered.map(chat => {
            const isActive = activeChat?._id === chat._id;
            const statusDot = getStatusColor(chat, user);
            const icon = getChatIcon(chat.type);
            const hasBot = chat.bots?.length > 0;

            return (
              <button
                key={chat._id}
                onClick={() => onSelectChat(chat)}
                className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl transition-all duration-150 text-left mb-0.5
                  ${isActive ? 'bg-primary-50 hover:bg-primary-100' : 'hover:bg-slate-50'}`}
              >
                {/* Avatar */}
                <div className="relative flex-shrink-0">
                  <Avatar
                    src={getChatAvatar(chat, user)}
                    name={getChatName(chat, user)}
                    size="md"
                  />
                  {statusDot && (
                    <span className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-white ${statusDot}`} />
                  )}
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1 min-w-0">
                      {icon && <span className="text-slate-400 flex-shrink-0">{icon}</span>}
                      <span className={`font-medium text-sm truncate ${isActive ? 'text-primary-700' : 'text-slate-800'}`}>
                        {getChatName(chat, user)}
                      </span>
                      {hasBot && <Bot size={11} className="text-primary-400 flex-shrink-0 ml-0.5" />}
                    </div>
                    {chat.lastActivity && (
                      <span className="text-xs text-slate-400 flex-shrink-0 ml-1">
                        {formatDistanceToNow(new Date(chat.lastActivity), { locale: ru, addSuffix: false })}
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-400 truncate mt-0.5">
                    {getLastMessagePreview(chat)}
                  </p>
                </div>
              </button>
            );
          })
        )}
      </div>

      {/* User profile bar */}
      <div className="px-3 py-3 border-t border-slate-100">
        <button
          onClick={onProfile}
          className="w-full flex items-center gap-3 p-2 rounded-xl hover:bg-slate-50 transition-colors text-left"
        >
          <div className="relative">
            <Avatar src={user?.avatar} name={user?.displayName || user?.username} size="sm" />
            <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border-2 border-white bg-green-400" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-slate-800 truncate">{user?.displayName || user?.username}</p>
            <p className="text-xs text-slate-400 truncate">@{user?.username}</p>
          </div>
          <Settings size={15} className="text-slate-400 flex-shrink-0" />
        </button>
      </div>
    </div>
  );
}
