import React, { useState, useEffect } from 'react';
import { X, Search, MessageCircle, Users, Hash, Check } from 'lucide-react';
import { usersAPI, chatsAPI } from '../../services/api';
import Avatar from '../ui/Avatar';
import toast from 'react-hot-toast';

export default function NewChatModal({ onClose, onCreated }) {
  const [type, setType]             = useState('direct'); // 'direct' | 'group' | 'channel'
  const [search, setSearch]         = useState('');
  const [users, setUsers]           = useState([]);
  const [selected, setSelected]     = useState([]);
  const [groupName, setGroupName]   = useState('');
  const [description, setDescription] = useState('');
  const [loading, setLoading]       = useState(false);
  const [searching, setSearching]   = useState(false);

  useEffect(() => {
    if (!search.trim()) { setUsers([]); return; }
    setSearching(true);
    const t = setTimeout(async () => {
      try {
        const { data } = await usersAPI.search(search);
        setUsers(data.users || []);
      } catch {}
      finally { setSearching(false); }
    }, 400);
    return () => clearTimeout(t);
  }, [search]);

  const toggleUser = (u) => {
    if (type === 'direct') {
      setSelected([u]);
    } else {
      setSelected(prev =>
        prev.find(p => p._id === u._id)
          ? prev.filter(p => p._id !== u._id)
          : [...prev, u]
      );
    }
  };

  const handleCreate = async () => {
    if (type === 'direct' && selected.length !== 1) {
      toast.error('Выберите пользователя');
      return;
    }
    if (type !== 'direct' && !groupName.trim()) {
      toast.error('Введите название');
      return;
    }

    setLoading(true);
    try {
      const { data } = await chatsAPI.create({
        type,
        name: groupName.trim() || null,
        description,
        memberIds: selected.map(u => u._id),
      });
      onCreated(data.chat);
      toast.success(type === 'direct' ? 'Чат открыт' : `${type === 'group' ? 'Группа' : 'Канал'} создан`);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Ошибка создания');
    } finally {
      setLoading(false);
    }
  };

  const typeConfig = {
    direct:  { label: 'Личный чат', icon: MessageCircle, color: 'text-blue-600 bg-blue-50', activeColor: 'bg-blue-500 text-white' },
    group:   { label: 'Группа',     icon: Users,          color: 'text-violet-600 bg-violet-50', activeColor: 'bg-violet-500 text-white' },
    channel: { label: 'Канал',      icon: Hash,           color: 'text-amber-600 bg-amber-50', activeColor: 'bg-amber-500 text-white' },
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="relative z-10 w-full max-w-md bg-white rounded-2xl shadow-2xl overflow-hidden animate-fade-up">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
          <h2 className="font-bold text-slate-800">Новый чат</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-500">
            <X size={18} />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {/* Type selector */}
          <div className="grid grid-cols-3 gap-2">
            {Object.entries(typeConfig).map(([key, cfg]) => {
              const Icon = cfg.icon;
              return (
                <button key={key}
                  onClick={() => { setType(key); setSelected([]); }}
                  className={`flex flex-col items-center gap-1.5 py-3 px-2 rounded-xl text-xs font-medium transition-all border-2 ${
                    type === key
                      ? 'border-primary-400 bg-primary-50 text-primary-700'
                      : 'border-transparent bg-slate-50 text-slate-600 hover:bg-slate-100'
                  }`}>
                  <Icon size={18} />
                  {cfg.label}
                </button>
              );
            })}
          </div>

          {/* Group/channel name */}
          {type !== 'direct' && (
            <div className="space-y-2">
              <input
                className="input-field"
                placeholder={type === 'group' ? 'Название группы' : 'Название канала'}
                value={groupName}
                onChange={e => setGroupName(e.target.value)}
              />
              <input
                className="input-field"
                placeholder="Описание (опционально)"
                value={description}
                onChange={e => setDescription(e.target.value)}
              />
            </div>
          )}

          {/* Selected users */}
          {selected.length > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {selected.map(u => (
                <div key={u._id}
                  className="flex items-center gap-1.5 bg-primary-100 text-primary-700 text-xs px-2.5 py-1 rounded-full">
                  <span>{u.displayName || u.username}</span>
                  <button onClick={() => setSelected(prev => prev.filter(p => p._id !== u._id))}>
                    <X size={11} />
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* User search */}
          <div>
            <div className="relative">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                className="input-field pl-8"
                placeholder="Поиск пользователей..."
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
            </div>

            {users.length > 0 && (
              <div className="mt-2 border border-slate-200 rounded-xl overflow-hidden max-h-52 overflow-y-auto">
                {users.map(u => {
                  const isSelected = selected.find(s => s._id === u._id);
                  return (
                    <button key={u._id}
                      onClick={() => toggleUser(u)}
                      className="w-full flex items-center gap-3 px-3 py-2.5 hover:bg-slate-50 transition-colors border-b border-slate-100 last:border-0">
                      <Avatar src={u.avatar} name={u.displayName || u.username} size="sm" />
                      <div className="flex-1 text-left min-w-0">
                        <p className="text-sm font-medium text-slate-800 truncate">{u.displayName || u.username}</p>
                        <p className="text-xs text-slate-400">@{u.username}</p>
                      </div>
                      {isSelected && <Check size={16} className="text-primary-500 flex-shrink-0" />}
                    </button>
                  );
                })}
              </div>
            )}
            {searching && (
              <p className="text-xs text-slate-400 text-center py-2">Поиск...</p>
            )}
          </div>

          <button
            onClick={handleCreate}
            disabled={loading || (type === 'direct' ? selected.length !== 1 : !groupName.trim())}
            className="btn-primary w-full py-3 flex items-center justify-center gap-2"
          >
            {loading
              ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              : `Создать ${type === 'direct' ? 'чат' : type === 'group' ? 'группу' : 'канал'}`}
          </button>
        </div>
      </div>
    </div>
  );
}
