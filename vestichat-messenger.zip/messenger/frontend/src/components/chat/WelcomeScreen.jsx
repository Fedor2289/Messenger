import React from 'react';
import { MessageCircle, Users, Hash, Bot, Zap } from 'lucide-react';

export default function WelcomeScreen({ onNewChat }) {
  const features = [
    { icon: MessageCircle, color: 'bg-blue-100 text-blue-600',   label: 'Личные чаты',     desc: 'Общайтесь один на один' },
    { icon: Users,         color: 'bg-violet-100 text-violet-600', label: 'Группы',          desc: 'Чаты для команды' },
    { icon: Hash,          color: 'bg-amber-100 text-amber-600',  label: 'Каналы',          desc: 'Публикуйте для всех' },
    { icon: Bot,           color: 'bg-green-100 text-green-600',  label: 'ИИ-боты',         desc: 'Истории, загадки, игры' },
  ];

  return (
    <div className="flex-1 flex flex-col items-center justify-center bg-slate-50 p-8">
      <div className="w-20 h-20 bg-primary-500 rounded-3xl flex items-center justify-center mb-5 shadow-xl shadow-primary-200">
        <MessageCircle size={40} className="text-white" />
      </div>
      <h2 className="text-2xl font-bold text-slate-800 mb-2">Добро пожаловать!</h2>
      <p className="text-slate-500 text-center mb-8 max-w-sm">
        Выберите чат слева или создайте новый — и начинайте общение прямо сейчас
      </p>

      <div className="grid grid-cols-2 gap-3 max-w-sm w-full mb-8">
        {features.map(({ icon: Icon, color, label, desc }) => (
          <div key={label} className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center mb-2 ${color}`}>
              <Icon size={18} />
            </div>
            <p className="text-sm font-semibold text-slate-700">{label}</p>
            <p className="text-xs text-slate-400 mt-0.5">{desc}</p>
          </div>
        ))}
      </div>

      <button
        onClick={onNewChat}
        className="btn-primary flex items-center gap-2 px-6 py-3 shadow-lg shadow-primary-200"
      >
        <Zap size={16} />
        Начать новый чат
      </button>
    </div>
  );
}
