import React from 'react';

const COLORS = [
  'bg-rose-400', 'bg-orange-400', 'bg-amber-400', 'bg-lime-500',
  'bg-emerald-500', 'bg-teal-500', 'bg-cyan-500', 'bg-sky-500',
  'bg-blue-500', 'bg-indigo-500', 'bg-violet-500', 'bg-fuchsia-500',
];

function getColor(name = '') {
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
  return COLORS[Math.abs(hash) % COLORS.length];
}

function getInitials(name = '') {
  const parts = name.trim().split(/\s+/);
  if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
  return name.slice(0, 2).toUpperCase() || '?';
}

const SIZES = {
  xs:  { div: 'w-6 h-6',   text: 'text-[9px]'  },
  sm:  { div: 'w-8 h-8',   text: 'text-xs'     },
  md:  { div: 'w-10 h-10', text: 'text-sm'     },
  lg:  { div: 'w-12 h-12', text: 'text-base'   },
  xl:  { div: 'w-16 h-16', text: 'text-xl'     },
  '2xl':{ div: 'w-20 h-20', text: 'text-2xl'   },
};

export default function Avatar({ src, name = '', size = 'md', className = '' }) {
  const cfg   = SIZES[size] || SIZES.md;
  const color = getColor(name);

  if (src) {
    return (
      <img
        src={src}
        alt={name}
        className={`${cfg.div} rounded-full object-cover flex-shrink-0 ${className}`}
        onError={e => {
          e.target.onerror = null;
          e.target.style.display = 'none';
          e.target.parentElement?.classList.add('show-fallback');
        }}
      />
    );
  }

  return (
    <div className={`${cfg.div} ${color} rounded-full flex items-center justify-center flex-shrink-0 ${className}`}>
      <span className={`${cfg.text} font-semibold text-white leading-none select-none`}>
        {getInitials(name)}
      </span>
    </div>
  );
}
