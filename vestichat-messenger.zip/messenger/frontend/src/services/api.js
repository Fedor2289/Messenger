import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || '/api',
  timeout: 30000,
});

// Attach JWT token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Handle 401
api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

export default api;

// ──── Auth ────
export const authAPI = {
  register: (data) => api.post('/auth/register', data),
  login:    (data) => api.post('/auth/login', data),
  me:       ()     => api.get('/auth/me'),
  logout:   ()     => api.post('/auth/logout'),
  updateProfile: (data) => api.put('/auth/profile', data),
  changePassword: (data) => api.put('/auth/password', data),
};

// ──── Users ────
export const usersAPI = {
  search:    (q)   => api.get('/users', { params: { search: q } }),
  getById:   (id)  => api.get(`/users/${id}`),
  getOnline: ()    => api.get('/users/online/list'),
};

// ──── Chats ────
export const chatsAPI = {
  getAll:        ()          => api.get('/chats'),
  getById:       (id)        => api.get(`/chats/${id}`),
  create:        (data)      => api.post('/chats', data),
  update:        (id, data)  => api.put(`/chats/${id}`, data),
  addMember:     (id, userId) => api.post(`/chats/${id}/members`, { userId }),
  removeMember:  (id, userId) => api.delete(`/chats/${id}/members/${userId}`),
  addBot:        (id, botId)  => api.post(`/chats/${id}/bots`, { botId }),
  removeBot:     (id, botId)  => api.delete(`/chats/${id}/bots/${botId}`),
  getPublic:     ()           => api.get('/chats/public/list'),
  joinByLink:    (link)       => api.post(`/chats/join/${link}`),
};

// ──── Messages ────
export const messagesAPI = {
  getByChatId: (chatId, page = 1) => api.get(`/messages/${chatId}`, { params: { page, limit: 50 } }),
  send:        (data)              => api.post('/messages', data),
  edit:        (id, content)       => api.put(`/messages/${id}`, { content }),
  delete:      (id)                => api.delete(`/messages/${id}`),
  react:       (id, emoji)         => api.post(`/messages/${id}/react`, { emoji }),
};

// ──── Files ────
export const filesAPI = {
  upload: (chatId, file, onProgress) => {
    const form = new FormData();
    form.append('file', file);
    form.append('chatId', chatId);
    return api.post('/files/upload', form, {
      headers: { 'Content-Type': 'multipart/form-data' },
      onUploadProgress: onProgress,
    });
  },
  uploadAvatar: (file) => {
    const form = new FormData();
    form.append('avatar', file);
    return api.post('/files/avatar', form, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
};

// ──── Bots ────
export const botsAPI = {
  getAll:   ()         => api.get('/bots'),
  getById:  (id)       => api.get(`/bots/${id}`),
  create:   (data)     => api.post('/bots', data),
  update:   (id, data) => api.put(`/bots/${id}`, data),
  delete:   (id)       => api.delete(`/bots/${id}`),
  test:     (id, msg)  => api.post(`/bots/${id}/test`, { message: msg }),
};

// ──── Admin ────
export const adminAPI = {
  getStats:    ()              => api.get('/admin/stats'),
  getUsers:    (params)        => api.get('/admin/users', { params }),
  updateUser:  (id, data)      => api.put(`/admin/users/${id}`, data),
  deleteUser:  (id)            => api.delete(`/admin/users/${id}`),
  getChats:    (params)        => api.get('/admin/chats', { params }),
  deleteChat:  (id)            => api.delete(`/admin/chats/${id}`),
  getBots:     ()              => api.get('/admin/bots'),
  setBotGlobal:(id, isGlobal)  => api.put(`/admin/bots/${id}/global`, { isGlobal }),
  seedBots:    ()              => api.post('/admin/bots/seed'),
};
